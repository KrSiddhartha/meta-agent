"""
Sadhaka ReAct Parser - Parse LLM outputs into structured actions
"""

import re
import json
from typing import Optional, Dict, Tuple, Any
from dataclasses import dataclass


@dataclass
class ParsedAction:
    """Parsed action from LLM output"""
    thought: str
    action: Optional[str]
    action_input: Optional[Any]
    final_answer: Optional[str]
    raw_text: str


class ReActParser:
    """
    Parse ReAct-style LLM outputs.
    
    Formats supported:
    1. Standard ReAct:
       Thought: ...
       Action: action_name
       Action Input: {...}
    
    2. Final Answer:
       Thought: ...
       Final Answer: ...
    
    3. JSON format:
       {"thought": "...", "action": "...", "action_input": {...}}
    """
    
    # Patterns for parsing
    THOUGHT_PATTERN = re.compile(r'Thought:\s*(.+?)(?=Action:|Final Answer:|$)', re.DOTALL | re.IGNORECASE)
    ACTION_PATTERN = re.compile(r'Action:\s*(\w+)', re.IGNORECASE)
    ACTION_INPUT_PATTERN = re.compile(r'Action Input:\s*(.+?)(?=Observation:|Thought:|$)', re.DOTALL | re.IGNORECASE)
    FINAL_ANSWER_PATTERN = re.compile(r'Final Answer:\s*(.+?)$', re.DOTALL | re.IGNORECASE)
    
    def parse(self, text: str) -> ParsedAction:
        """Parse LLM output into structured action"""
        text = text.strip()
        
        # Try JSON format first
        if text.startswith('{'):
            try:
                return self._parse_json(text)
            except (json.JSONDecodeError, KeyError):
                pass
        
        # Try standard ReAct format
        return self._parse_react(text)
    
    def _parse_react(self, text: str) -> ParsedAction:
        """Parse standard ReAct format"""
        thought = ""
        action = None
        action_input = None
        final_answer = None
        
        # Extract thought
        thought_match = self.THOUGHT_PATTERN.search(text)
        if thought_match:
            thought = thought_match.group(1).strip()
        
        # Check for final answer
        final_match = self.FINAL_ANSWER_PATTERN.search(text)
        if final_match:
            final_answer = final_match.group(1).strip()
            return ParsedAction(
                thought=thought,
                action=None,
                action_input=None,
                final_answer=final_answer,
                raw_text=text,
            )
        
        # Extract action
        action_match = self.ACTION_PATTERN.search(text)
        if action_match:
            action = action_match.group(1).strip()
        
        # Extract action input
        input_match = self.ACTION_INPUT_PATTERN.search(text)
        if input_match:
            input_text = input_match.group(1).strip()
            action_input = self._parse_action_input(input_text)
        
        return ParsedAction(
            thought=thought,
            action=action,
            action_input=action_input,
            final_answer=None,
            raw_text=text,
        )
    
    def _parse_json(self, text: str) -> ParsedAction:
        """Parse JSON format"""
        # Find the first { and match to the corresponding closing }
        start = text.find('{')
        if start == -1:
            raise json.JSONDecodeError("No JSON found", text, 0)
        
        # Count braces to find matching end
        depth = 0
        for i, c in enumerate(text[start:], start):
            if c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
                if depth == 0:
                    json_str = text[start:i+1]
                    break
        else:
            raise json.JSONDecodeError("Unmatched braces", text, 0)
        
        data = json.loads(json_str)
        
        return ParsedAction(
            thought=data.get("thought", ""),
            action=data.get("action"),
            action_input=data.get("action_input"),
            final_answer=data.get("final_answer"),
            raw_text=text,
        )
    
    def _parse_action_input(self, text: str) -> Any:
        """Parse action input - try JSON first, then plain text"""
        text = text.strip()
        
        # Try to parse as JSON
        if text.startswith('{') or text.startswith('['):
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                # Try to fix common JSON issues
                fixed = self._fix_json(text)
                try:
                    return json.loads(fixed)
                except json.JSONDecodeError:
                    pass
        
        # Return as plain text
        return text
    
    def _fix_json(self, text: str) -> str:
        """Attempt to fix common JSON issues"""
        # Remove trailing commas
        text = re.sub(r',\s*}', '}', text)
        text = re.sub(r',\s*]', ']', text)
        
        # Fix single quotes
        text = text.replace("'", '"')
        
        # Fix unquoted keys
        text = re.sub(r'(\w+):', r'"\1":', text)
        
        return text
    
    def format_observation(self, observation: Any) -> str:
        """Format observation for next prompt"""
        if isinstance(observation, dict):
            return f"Observation: {json.dumps(observation, indent=2)}"
        elif isinstance(observation, str):
            return f"Observation: {observation}"
        else:
            return f"Observation: {str(observation)}"
    
    def format_prompt_continuation(
        self,
        thought: str,
        action: str,
        action_input: Any,
        observation: Any,
    ) -> str:
        """Format the continuation prompt after an action"""
        input_str = json.dumps(action_input) if isinstance(action_input, (dict, list)) else str(action_input)
        obs_str = json.dumps(observation) if isinstance(observation, (dict, list)) else str(observation)
        
        return f"""Thought: {thought}
Action: {action}
Action Input: {input_str}
Observation: {obs_str}

"""
