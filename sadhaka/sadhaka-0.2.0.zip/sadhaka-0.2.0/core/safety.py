"""
Sadhaka Safety Guards - Prevent infinite loops, resource leaks, and dangerous patterns

Addresses ChatGPT review concerns:
- "Infinite tool-calling loops"
- "Resource leakage"
- "Stateless tools causing inconsistencies"
"""

import time
import logging
from typing import Dict, List, Set, Optional, Any
from dataclasses import dataclass, field
from collections import defaultdict

logger = logging.getLogger(__name__)


@dataclass
class LoopDetector:
    """
    Detects and prevents infinite tool-calling loops.
    
    Patterns detected:
    1. Same tool called N times in a row with identical inputs
    2. Cycle of tools repeated (A→B→A→B→A→B)
    3. Total tool calls exceeding limit
    """
    
    max_identical_calls: int = 3  # Max identical tool+input in a row
    max_cycle_length: int = 10   # Max tools before checking for cycles
    max_total_calls: int = 50    # Absolute limit per task
    
    # State
    call_history: List[Dict] = field(default_factory=list)
    tool_input_counts: Dict[str, int] = field(default_factory=lambda: defaultdict(int))
    
    def record_call(self, tool: str, input_data: Any) -> None:
        """Record a tool call"""
        key = f"{tool}:{hash(str(input_data))}"
        self.call_history.append({"tool": tool, "input_hash": hash(str(input_data)), "key": key})
        self.tool_input_counts[key] += 1
    
    def check_for_loop(self, tool: str, input_data: Any) -> Optional[str]:
        """
        Check if this call would create a loop.
        
        Returns: Error message if loop detected, None otherwise
        """
        key = f"{tool}:{hash(str(input_data))}"
        
        # Check 1: Same tool+input called too many times
        if self.tool_input_counts[key] >= self.max_identical_calls:
            return f"Loop detected: {tool} called {self.tool_input_counts[key]} times with same input"
        
        # Check 2: Total calls exceeded
        if len(self.call_history) >= self.max_total_calls:
            return f"Maximum tool calls ({self.max_total_calls}) exceeded"
        
        # Check 3: Cycle detection (last N calls repeat earlier pattern)
        if len(self.call_history) >= self.max_cycle_length:
            pattern = self._detect_cycle()
            if pattern:
                return f"Cycle detected: {' → '.join(pattern)} repeating"
        
        return None
    
    def _detect_cycle(self) -> Optional[List[str]]:
        """Detect repeating cycle in recent history"""
        recent = [h["tool"] for h in self.call_history[-self.max_cycle_length:]]
        
        # Check for patterns of length 2-5
        for pattern_len in range(2, 6):
            if len(recent) < pattern_len * 2:
                continue
            
            pattern = recent[-pattern_len:]
            prev_pattern = recent[-pattern_len*2:-pattern_len]
            
            if pattern == prev_pattern:
                return pattern
        
        return None
    
    def reset(self):
        """Reset state for new task"""
        self.call_history.clear()
        self.tool_input_counts.clear()


@dataclass
class ResourceTracker:
    """
    Track and clean up resources created during execution.
    
    Prevents resource leaks from:
    - Spawned processes
    - Open file handles
    - Network connections
    - Temporary files
    """
    
    processes: List[Any] = field(default_factory=list)
    temp_files: List[str] = field(default_factory=list)
    containers: List[str] = field(default_factory=list)
    connections: List[Any] = field(default_factory=list)
    
    def register_process(self, process: Any) -> None:
        """Register a spawned process for cleanup"""
        self.processes.append(process)
        logger.debug(f"Registered process: {process}")
    
    def register_temp_file(self, path: str) -> None:
        """Register a temporary file for cleanup"""
        self.temp_files.append(path)
        logger.debug(f"Registered temp file: {path}")
    
    def register_container(self, container_id: str) -> None:
        """Register a Docker container for cleanup"""
        self.containers.append(container_id)
        logger.debug(f"Registered container: {container_id}")
    
    def register_connection(self, conn: Any) -> None:
        """Register a network connection for cleanup"""
        self.connections.append(conn)
        logger.debug(f"Registered connection: {conn}")
    
    def cleanup_all(self) -> Dict[str, int]:
        """Clean up all registered resources"""
        results = {
            "processes_killed": 0,
            "files_deleted": 0,
            "containers_removed": 0,
            "connections_closed": 0,
            "errors": [],
        }
        
        # Kill processes
        for proc in self.processes:
            try:
                if hasattr(proc, 'kill'):
                    proc.kill()
                elif hasattr(proc, 'terminate'):
                    proc.terminate()
                results["processes_killed"] += 1
            except Exception as e:
                results["errors"].append(f"Process cleanup: {e}")
        
        # Delete temp files
        import os
        import shutil
        for path in self.temp_files:
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path, ignore_errors=True)
                elif os.path.exists(path):
                    os.remove(path)
                results["files_deleted"] += 1
            except Exception as e:
                results["errors"].append(f"File cleanup {path}: {e}")
        
        # Remove containers (requires docker client)
        for container_id in self.containers:
            try:
                import docker
                client = docker.from_env()
                container = client.containers.get(container_id)
                container.remove(force=True)
                results["containers_removed"] += 1
            except Exception as e:
                results["errors"].append(f"Container cleanup {container_id}: {e}")
        
        # Close connections
        for conn in self.connections:
            try:
                if hasattr(conn, 'close'):
                    conn.close()
                results["connections_closed"] += 1
            except Exception as e:
                results["errors"].append(f"Connection cleanup: {e}")
        
        # Clear registrations
        self.processes.clear()
        self.temp_files.clear()
        self.containers.clear()
        self.connections.clear()
        
        if results["errors"]:
            logger.warning(f"Cleanup completed with errors: {results['errors']}")
        else:
            logger.info(f"Cleanup completed: {results}")
        
        return results


@dataclass
class OutputValidator:
    """
    Validate and sanitize LLM outputs before processing.
    
    Prevents:
    - Malformed JSON breaking the agent loop
    - Injection attacks in tool inputs
    - Excessively long outputs
    """
    
    max_output_length: int = 10000
    max_tool_input_length: int = 5000
    
    # Dangerous patterns to block
    dangerous_patterns: List[str] = field(default_factory=lambda: [
        "rm -rf",
        "sudo",
        "; rm ",
        "| rm ",
        "DROP TABLE",
        "DELETE FROM",
        "__import__",
        "eval(",
        "exec(",
        "os.system",
        "subprocess.call",
    ])
    
    def validate_output(self, text: str) -> tuple:
        """
        Validate LLM output.
        
        Returns: (is_valid, cleaned_text_or_error)
        """
        if not text:
            return False, "Empty output"
        
        if len(text) > self.max_output_length:
            return False, f"Output too long ({len(text)} > {self.max_output_length})"
        
        return True, text
    
    def validate_tool_input(self, tool: str, input_data: Any) -> tuple:
        """
        Validate tool input for safety.
        
        Returns: (is_valid, cleaned_input_or_error)
        """
        input_str = str(input_data)
        
        # Length check
        if len(input_str) > self.max_tool_input_length:
            return False, f"Tool input too long ({len(input_str)} > {self.max_tool_input_length})"
        
        # Dangerous pattern check
        input_lower = input_str.lower()
        for pattern in self.dangerous_patterns:
            if pattern.lower() in input_lower:
                return False, f"Dangerous pattern detected: {pattern}"
        
        return True, input_data
    
    def sanitize_for_logging(self, text: str, max_length: int = 500) -> str:
        """Sanitize text for safe logging"""
        if len(text) > max_length:
            return text[:max_length] + "...[truncated]"
        return text


class SafetyGuard:
    """
    Combined safety guard for agent execution.
    
    Usage:
        guard = SafetyGuard()
        
        # Before each tool call
        error = guard.pre_tool_call("calculator", {"expression": "2+2"})
        if error:
            return error  # Block the call
        
        # After task completes
        guard.cleanup()
    """
    
    def __init__(
        self,
        max_identical_calls: int = 3,
        max_total_calls: int = 50,
        max_output_length: int = 10000,
    ):
        self.loop_detector = LoopDetector(
            max_identical_calls=max_identical_calls,
            max_total_calls=max_total_calls,
        )
        self.resource_tracker = ResourceTracker()
        self.output_validator = OutputValidator(
            max_output_length=max_output_length,
        )
        self.start_time = time.time()
        self.max_execution_time = 300  # 5 minutes default
    
    def pre_tool_call(self, tool: str, input_data: Any) -> Optional[str]:
        """
        Check before making a tool call.
        
        Returns: Error message if call should be blocked, None if OK
        """
        # Check execution time
        if time.time() - self.start_time > self.max_execution_time:
            return f"Maximum execution time ({self.max_execution_time}s) exceeded"
        
        # Check for loops
        loop_error = self.loop_detector.check_for_loop(tool, input_data)
        if loop_error:
            return loop_error
        
        # Validate input
        is_valid, result = self.output_validator.validate_tool_input(tool, input_data)
        if not is_valid:
            return result
        
        # Record the call
        self.loop_detector.record_call(tool, input_data)
        
        return None
    
    def validate_llm_output(self, text: str) -> tuple:
        """Validate LLM output"""
        return self.output_validator.validate_output(text)
    
    def register_resource(self, resource_type: str, resource: Any):
        """Register a resource for cleanup"""
        if resource_type == "process":
            self.resource_tracker.register_process(resource)
        elif resource_type == "file":
            self.resource_tracker.register_temp_file(resource)
        elif resource_type == "container":
            self.resource_tracker.register_container(resource)
        elif resource_type == "connection":
            self.resource_tracker.register_connection(resource)
    
    def cleanup(self) -> Dict:
        """Clean up all resources and reset state"""
        cleanup_result = self.resource_tracker.cleanup_all()
        self.loop_detector.reset()
        self.start_time = time.time()
        return cleanup_result
    
    def get_stats(self) -> Dict:
        """Get current safety guard statistics"""
        return {
            "execution_time_seconds": round(time.time() - self.start_time, 1),
            "tool_calls": len(self.loop_detector.call_history),
            "unique_tool_inputs": len(self.loop_detector.tool_input_counts),
            "registered_processes": len(self.resource_tracker.processes),
            "registered_temp_files": len(self.resource_tracker.temp_files),
            "registered_containers": len(self.resource_tracker.containers),
        }
