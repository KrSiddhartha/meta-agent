"""
Sadhaka Tools - Tool registry and execution

Pillar 2: Explicit Tools
"Tools must have clear signatures and return types to eliminate guesswork"
"""

import json
import time
import ast
import logging
from typing import Optional, Dict, List, Any, Callable
from dataclasses import dataclass, field
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class ToolInput(BaseModel):
    """Base model for tool inputs - provides validation"""
    pass


class ToolOutput(BaseModel):
    """Base model for tool outputs"""
    success: bool
    result: Any = None
    error: Optional[str] = None


@dataclass
class Tool:
    """Tool definition with schema"""
    name: str
    description: str
    input_schema: Dict
    output_schema: Dict
    function: Optional[Callable] = None
    source_code: Optional[str] = None
    version: int = 1
    created_at: float = field(default_factory=time.time)
    created_by: str = "system"


class ToolRegistry:
    """
    Registry for tools with validation and execution.
    
    Features:
    - Pydantic validation on inputs
    - Schema-based tool definitions
    - Dynamic tool creation from source code
    - Safe execution with AST validation
    """
    
    # Dangerous patterns for AST validation
    DANGEROUS_PATTERNS = [
        "import os",
        "import subprocess",
        "import sys",
        "import socket",
        "__import__",
        "exec(",
        "eval(",
        "compile(",
        "open(",
        "file(",
    ]
    
    SAFE_MODULES = [
        "json",
        "math",
        "re",
        "datetime",
        "collections",
        "itertools",
        "functools",
        "operator",
        "string",
        "random",
        "hashlib",
        "base64",
        "urllib.parse",
        "typing",
    ]
    
    def __init__(self, milvus_client=None):
        self.milvus = milvus_client
        self.tools: Dict[str, Tool] = {}
        self._register_builtin_tools()
    
    def _register_builtin_tools(self):
        """Register built-in tools"""
        # Calculator tool
        self.register(Tool(
            name="calculator",
            description="Perform mathematical calculations. Supports +, -, *, /, **, sqrt, sin, cos, tan, log.",
            input_schema={
                "type": "object",
                "properties": {
                    "expression": {"type": "string", "description": "Mathematical expression to evaluate"}
                },
                "required": ["expression"]
            },
            output_schema={
                "type": "object",
                "properties": {
                    "result": {"type": "number"},
                    "expression": {"type": "string"}
                }
            },
            function=self._calculator,
        ))
        
        # JSON parser tool
        self.register(Tool(
            name="json_parser",
            description="Parse and extract data from JSON strings.",
            input_schema={
                "type": "object",
                "properties": {
                    "json_string": {"type": "string", "description": "JSON string to parse"},
                    "path": {"type": "string", "description": "Optional dot-notation path to extract (e.g., 'data.items.0')"}
                },
                "required": ["json_string"]
            },
            output_schema={
                "type": "object",
                "properties": {
                    "parsed": {"type": "any"},
                    "extracted": {"type": "any"}
                }
            },
            function=self._json_parser,
        ))
        
        # String operations tool
        self.register(Tool(
            name="string_ops",
            description="Perform string operations: upper, lower, split, join, replace, find.",
            input_schema={
                "type": "object",
                "properties": {
                    "operation": {"type": "string", "enum": ["upper", "lower", "split", "join", "replace", "find", "strip", "count"]},
                    "text": {"type": "string"},
                    "arg1": {"type": "string", "description": "First argument (delimiter for split/join, search for replace/find)"},
                    "arg2": {"type": "string", "description": "Second argument (replacement for replace)"}
                },
                "required": ["operation", "text"]
            },
            output_schema={
                "type": "object",
                "properties": {
                    "result": {"type": "any"}
                }
            },
            function=self._string_ops,
        ))
    
    def _calculator(self, expression: str) -> Dict:
        """Safe calculator implementation"""
        import math
        
        # Whitelist of allowed names
        allowed_names = {
            'abs': abs, 'round': round, 'min': min, 'max': max,
            'sum': sum, 'pow': pow, 'sqrt': math.sqrt,
            'sin': math.sin, 'cos': math.cos, 'tan': math.tan,
            'log': math.log, 'log10': math.log10, 'exp': math.exp,
            'pi': math.pi, 'e': math.e,
        }
        
        try:
            # Parse and validate
            tree = ast.parse(expression, mode='eval')
            
            # Check for only allowed operations
            for node in ast.walk(tree):
                if isinstance(node, ast.Name) and node.id not in allowed_names:
                    raise ValueError(f"Unauthorized name: {node.id}")
                if isinstance(node, ast.Call):
                    if isinstance(node.func, ast.Name) and node.func.id not in allowed_names:
                        raise ValueError(f"Unauthorized function: {node.func.id}")
            
            result = eval(compile(tree, '<string>', 'eval'), {"__builtins__": {}}, allowed_names)
            return {"success": True, "result": result, "expression": expression}
        except Exception as e:
            return {"success": False, "error": str(e), "expression": expression}
    
    def _json_parser(self, json_string: str, path: str = None) -> Dict:
        """Parse JSON and optionally extract by path"""
        try:
            parsed = json.loads(json_string)
            
            extracted = parsed
            if path:
                for key in path.split('.'):
                    if isinstance(extracted, dict):
                        extracted = extracted.get(key)
                    elif isinstance(extracted, list) and key.isdigit():
                        extracted = extracted[int(key)]
                    else:
                        extracted = None
                        break
            
            return {"success": True, "parsed": parsed, "extracted": extracted}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def _string_ops(self, operation: str, text: str, arg1: str = None, arg2: str = None) -> Dict:
        """String operations"""
        try:
            if operation == "upper":
                result = text.upper()
            elif operation == "lower":
                result = text.lower()
            elif operation == "split":
                result = text.split(arg1 or " ")
            elif operation == "join":
                result = (arg1 or "").join(text)
            elif operation == "replace":
                result = text.replace(arg1 or "", arg2 or "")
            elif operation == "find":
                result = text.find(arg1 or "")
            elif operation == "strip":
                result = text.strip(arg1)
            elif operation == "count":
                result = text.count(arg1 or "")
            else:
                return {"success": False, "error": f"Unknown operation: {operation}"}
            
            return {"success": True, "result": result}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    # =========================================================================
    # REGISTRY OPERATIONS
    # =========================================================================
    
    def register(self, tool: Tool):
        """Register a tool"""
        self.tools[tool.name] = tool
        
        if self.milvus:
            self._save_to_milvus(tool)
        
        logger.info(f"Registered tool: {tool.name}")
    
    def get(self, name: str) -> Optional[Tool]:
        """Get a tool by name"""
        return self.tools.get(name)
    
    def list_tools(self) -> List[Dict]:
        """List all tools"""
        return [
            {
                "name": t.name,
                "description": t.description,
                "input_schema": t.input_schema,
            }
            for t in self.tools.values()
        ]
    
    def execute(self, name: str, **kwargs) -> Dict:
        """Execute a tool by name"""
        tool = self.tools.get(name)
        if not tool:
            return {"success": False, "error": f"Tool not found: {name}"}
        
        try:
            if tool.function:
                result = tool.function(**kwargs)
            elif tool.source_code:
                result = self._execute_source(tool.source_code, kwargs)
            else:
                return {"success": False, "error": "Tool has no executable code"}
            
            return result if isinstance(result, dict) else {"success": True, "result": result}
        except Exception as e:
            logger.error(f"Tool execution failed: {name}: {e}")
            return {"success": False, "error": str(e)}
    
    # =========================================================================
    # DYNAMIC TOOL CREATION
    # =========================================================================
    
    def create_tool(
        self,
        name: str,
        description: str,
        source_code: str,
        input_schema: Dict = None,
        output_schema: Dict = None,
        created_by: str = "agent",
    ) -> Tool:
        """
        Create a new tool from source code.
        
        Source code must be safe (validated with AST).
        """
        # Validate source code
        is_safe, error = self.validate_code(source_code)
        if not is_safe:
            raise ValueError(f"Unsafe code: {error}")
        
        tool = Tool(
            name=name,
            description=description,
            source_code=source_code,
            input_schema=input_schema or {"type": "object", "properties": {}},
            output_schema=output_schema or {"type": "object"},
            created_by=created_by,
        )
        
        self.register(tool)
        return tool
    
    def validate_code(self, code: str) -> tuple:
        """Validate code for safety"""
        # Check for dangerous patterns
        for pattern in self.DANGEROUS_PATTERNS:
            if pattern in code:
                return False, f"Dangerous pattern: {pattern}"
        
        # Parse AST
        try:
            tree = ast.parse(code)
        except SyntaxError as e:
            return False, f"Syntax error: {e}"
        
        # Check imports
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name.split('.')[0] not in self.SAFE_MODULES:
                        return False, f"Unsafe import: {alias.name}"
            elif isinstance(node, ast.ImportFrom):
                if node.module and node.module.split('.')[0] not in self.SAFE_MODULES:
                    return False, f"Unsafe import from: {node.module}"
        
        return True, None
    
    def _execute_source(self, source_code: str, inputs: Dict) -> Any:
        """Execute source code with inputs"""
        import math
        import json as json_module
        import re as re_module
        from datetime import datetime
        
        # Safe globals
        safe_globals = {
            "__builtins__": {
                "abs": abs, "all": all, "any": any, "bin": bin,
                "bool": bool, "chr": chr, "dict": dict, "enumerate": enumerate,
                "filter": filter, "float": float, "format": format,
                "frozenset": frozenset, "hex": hex, "int": int, "isinstance": isinstance,
                "len": len, "list": list, "map": map, "max": max, "min": min,
                "oct": oct, "ord": ord, "pow": pow, "print": print, "range": range,
                "repr": repr, "reversed": reversed, "round": round, "set": set,
                "slice": slice, "sorted": sorted, "str": str, "sum": sum,
                "tuple": tuple, "type": type, "zip": zip,
                "True": True, "False": False, "None": None,
            },
            "math": math,
            "json": json_module,
            "re": re_module,
            "datetime": datetime,
        }
        
        # Add inputs
        local_vars = dict(inputs)
        
        # Execute
        exec(source_code, safe_globals, local_vars)
        
        # Look for result
        if "result" in local_vars:
            return local_vars["result"]
        elif "output" in local_vars:
            return local_vars["output"]
        else:
            return {"executed": True}
    
    def _save_to_milvus(self, tool: Tool):
        """Save tool to Milvus"""
        if not self.milvus:
            return
        
        self.milvus.upsert("tools", {
            "id": f"tool_{tool.name}_v{tool.version}",
            "name": tool.name,
            "version": tool.version,
            "version_tag": f"{tool.version}.0.0",
            "description": tool.description,
            "source_code": tool.source_code or "",
            "input_schema": json.dumps(tool.input_schema),
            "output_schema": json.dumps(tool.output_schema),
            "health_score": 1.0,
            "health_status": "healthy",
            "total_executions": 0,
            "successful_executions": 0,
            "failed_executions": 0,
            "avg_execution_time_ms": 0.0,
            "last_execution_at": 0,
            "last_failure_at": 0,
            "consecutive_failures": 0,
            "error_types_json": "{}",
            "created_at": int(tool.created_at),
            "created_by": tool.created_by,
            "deprecated_at": 0,
            "deprecation_reason": "",
            "replaced_by": "",
            "parent_version_id": "",
            "embedding": [0.0] * 1024,
        })
