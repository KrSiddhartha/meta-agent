"""
Sadhaka Agent - Main agent with ReAct loop and all integrations

Integrates:
- vLLM with KV-cache sharing (Latent Collaboration)
- Blackboard pattern (Milvus state)
- Docker execution (Ephemeral + Persistent)
- Goal tree (Pillar 3)
- Recovery engine (Pillar 4)
- Health tracking
"""

import asyncio
import time
import uuid
import logging
from typing import Optional, Dict, List, Any

from ..llm.vllm_provider import VLLMLatentProvider, GenerationResult
from ..memory.milvus_client import MilvusClient
from ..memory.health_manager import HealthManager, EntityType, HealthUpdate
from ..orchestration.blackboard import Blackboard
from ..runtime.docker_manager import DockerManager, ContainerSpec, ContainerLifecycle
from ..goals.goal_tree import GoalTree, GoalStatus
from ..recovery.recovery_engine import RecoveryEngine, FailureType
from ..core.parser import ReActParser, ParsedAction
from ..core.tools import ToolRegistry
from ..config import SadhakaConfig, DEFAULT_CONFIG

logger = logging.getLogger(__name__)


class SadhakaAgent:
    """
    Main Sadhaka agent implementing the 4 pillars:
    
    1. Durable Memory (Milvus + Blackboard)
    2. Explicit Tools (ToolRegistry with schemas)
    3. Specific Goal Definition (GoalTree)
    4. Recovery Logic (RecoveryEngine)
    
    Plus: Latent Collaboration via vLLM KV-cache sharing
    """
    
    def __init__(
        self,
        agent_id: str = None,
        config: SadhakaConfig = None,
        llm: VLLMLatentProvider = None,
        milvus: MilvusClient = None,
    ):
        self.agent_id = agent_id or f"agent_{uuid.uuid4().hex[:8]}"
        self.config = config or DEFAULT_CONFIG
        
        # Core components
        self.llm = llm or VLLMLatentProvider(
            model=self.config.vllm.model,
            tensor_parallel_size=self.config.vllm.tensor_parallel_size,
            gpu_memory_utilization=self.config.vllm.gpu_memory_utilization,
            max_model_len=self.config.vllm.max_model_len,
        )
        
        self.milvus = milvus or MilvusClient(
            uri=self.config.milvus.uri,
            db_name=self.config.milvus.db_name,
        )
        
        # Pillar components
        self.tools = ToolRegistry(self.milvus)
        self.health = HealthManager(self.milvus)
        self.recovery = RecoveryEngine(self.milvus)
        self.docker = DockerManager(self.config.docker.workspace_dir)
        self.goal_tree = GoalTree(self.milvus)
        self.parser = ReActParser()
        
        # Current task state
        self.current_task_id: Optional[str] = None
        self.blackboard: Optional[Blackboard] = None
        self.context_id: Optional[str] = None
        
        # Conversation history for ReAct loop
        self.history: List[str] = []
        self.max_iterations = 10
        
        logger.info(f"SadhakaAgent {self.agent_id} initialized")
    
    # =========================================================================
    # MAIN ENTRY POINT
    # =========================================================================
    
    async def run(
        self,
        task: str,
        goal_description: str = None,
        success_criteria: List[str] = None,
    ) -> Dict:
        """
        Run a task with full agent capabilities.
        
        Args:
            task: Task description
            goal_description: Optional explicit goal
            success_criteria: Optional success criteria
        
        Returns:
            Result dictionary with answer and metadata
        """
        # Initialize task
        self.current_task_id = f"task_{uuid.uuid4().hex[:8]}"
        self.blackboard = Blackboard(self.milvus, self.current_task_id)
        self.history = []
        
        # Create goal (Pillar 3)
        goal = self.goal_tree.create_root_goal(
            task_id=self.current_task_id,
            description=goal_description or task,
            success_criteria=success_criteria or ["Complete the task successfully"],
        )
        
        # Write initial state to blackboard
        self.blackboard.write_sync("task", task, self.agent_id)
        self.blackboard.write_sync("goal_id", goal.id, self.agent_id)
        self.blackboard.write_sync("status", "running", self.agent_id)
        
        # Create shared context for KV-cache sharing
        self.context_id = f"ctx_{self.current_task_id}"
        self._create_shared_context()
        
        # Run ReAct loop
        try:
            result = await self._react_loop(task)
            
            # Update goal status
            self.goal_tree.complete_goal(goal.id)
            self.blackboard.write_sync("status", "completed", self.agent_id)
            
            return {
                "success": True,
                "answer": result,
                "task_id": self.current_task_id,
                "goal_id": goal.id,
                "iterations": len(self.history),
            }
            
        except Exception as e:
            logger.error(f"Task failed: {e}")
            self.goal_tree.fail_goal(goal.id)
            self.blackboard.write_sync("status", "failed", self.agent_id)
            
            return {
                "success": False,
                "error": str(e),
                "task_id": self.current_task_id,
                "iterations": len(self.history),
            }
    
    def run_sync(self, task: str, **kwargs) -> Dict:
        """Synchronous wrapper for run()"""
        return asyncio.run(self.run(task, **kwargs))
    
    # =========================================================================
    # REACT LOOP
    # =========================================================================
    
    async def _react_loop(self, task: str) -> str:
        """
        ReAct reasoning loop.
        
        Thought → Action → Observation → Repeat until Final Answer
        """
        prompt = f"Task: {task}\n\nBegin reasoning:\n"
        self.history.append(prompt)
        
        for iteration in range(self.max_iterations):
            logger.debug(f"ReAct iteration {iteration + 1}")
            
            # Generate thought/action using shared context
            full_prompt = "\n".join(self.history)
            
            result = await self._generate_with_recovery(full_prompt)
            
            # Parse the response
            parsed = self.parser.parse(result.text)
            
            # Record to blackboard
            self.blackboard.write_sync(
                f"step_{iteration}",
                {
                    "thought": parsed.thought,
                    "action": parsed.action,
                    "action_input": parsed.action_input,
                },
                self.agent_id,
            )
            
            # Check for final answer
            if parsed.final_answer:
                self.history.append(result.text)
                return parsed.final_answer
            
            # Execute action
            if parsed.action:
                observation = await self._execute_action(parsed.action, parsed.action_input)
                
                # Format and add to history
                continuation = self.parser.format_prompt_continuation(
                    parsed.thought,
                    parsed.action,
                    parsed.action_input,
                    observation,
                )
                self.history.append(result.text)
                self.history.append(f"Observation: {observation}\n")
            else:
                # No action, add response and continue
                self.history.append(result.text)
        
        # Max iterations reached
        return "Maximum iterations reached without final answer"
    
    async def _generate_with_recovery(self, prompt: str) -> GenerationResult:
        """Generate with recovery logic"""
        return await self.recovery.execute_with_recovery(
            self._generate,
            prompt,
            service_name="llm",
            failure_type=FailureType.LLM_ERROR,
        )
    
    async def _generate(self, prompt: str) -> GenerationResult:
        """Generate using vLLM with shared context"""
        return self.llm.generate(
            prompt=prompt,
            agent_id=self.agent_id,
            context_id=self.context_id,
        )
    
    # =========================================================================
    # ACTION EXECUTION
    # =========================================================================
    
    async def _execute_action(self, action: str, action_input: Any) -> str:
        """Execute an action and return observation"""
        action_lower = action.lower()
        
        # Parse action input
        if isinstance(action_input, str):
            try:
                action_input = eval(action_input) if action_input.startswith('{') else {"input": action_input}
            except:
                action_input = {"input": action_input}
        elif not isinstance(action_input, dict):
            action_input = {"input": action_input}
        
        try:
            if action_lower == "use_tool" or action_lower in self.tools.tools:
                return await self._execute_tool(action_lower, action_input)
            
            elif action_lower == "execute_code":
                return await self._execute_code(action_input)
            
            elif action_lower == "create_tool":
                return await self._create_tool(action_input)
            
            elif action_lower == "read_blackboard":
                return await self._read_blackboard(action_input)
            
            elif action_lower == "write_blackboard":
                return await self._write_blackboard(action_input)
            
            elif action_lower == "check_goal":
                return await self._check_goal(action_input)
            
            else:
                # Try as tool name
                if action_lower in self.tools.tools:
                    return await self._execute_tool(action_lower, action_input)
                return f"Unknown action: {action}"
                
        except Exception as e:
            logger.error(f"Action execution failed: {action}: {e}")
            return f"Error executing {action}: {str(e)}"
    
    async def _execute_tool(self, tool_name: str, inputs: Dict) -> str:
        """Execute a tool with health tracking"""
        # Normalize tool name
        if tool_name == "use_tool":
            tool_name = inputs.pop("tool", inputs.pop("name", "unknown"))
        
        start_time = time.time()
        
        result = await self.recovery.execute_with_recovery(
            lambda: self.tools.execute(tool_name, **inputs),
            service_name=f"tool_{tool_name}",
            failure_type=FailureType.TOOL_ERROR,
        )
        
        execution_time = (time.time() - start_time) * 1000
        
        # Record health
        self.health.record_execution(
            EntityType.TOOL,
            f"tool_{tool_name}_v1",
            HealthUpdate(
                success=result.get("success", False),
                execution_time_ms=execution_time,
                error_type=None if result.get("success") else "execution_error",
            ),
        )
        
        return str(result)
    
    async def _execute_code(self, inputs: Dict) -> str:
        """Execute code in Docker container"""
        code = inputs.get("code", inputs.get("input", ""))
        
        result = await self.docker.run_ephemeral(
            code=code,
            spec=ContainerSpec(
                name=f"exec_{uuid.uuid4().hex[:8]}",
                lifecycle=ContainerLifecycle.EPHEMERAL,
                timeout=self.config.docker.default_timeout,
            ),
        )
        
        if result.success:
            return f"Output:\n{result.stdout}"
        else:
            return f"Error:\n{result.stderr}"
    
    async def _create_tool(self, inputs: Dict) -> str:
        """Create a new tool"""
        try:
            tool = self.tools.create_tool(
                name=inputs.get("name", f"tool_{uuid.uuid4().hex[:8]}"),
                description=inputs.get("description", "Custom tool"),
                source_code=inputs.get("code", inputs.get("source_code", "")),
                input_schema=inputs.get("input_schema"),
                output_schema=inputs.get("output_schema"),
                created_by=self.agent_id,
            )
            return f"Created tool: {tool.name}"
        except Exception as e:
            return f"Failed to create tool: {e}"
    
    async def _read_blackboard(self, inputs: Dict) -> str:
        """Read from blackboard"""
        key = inputs.get("key")
        if key:
            value = self.blackboard.read_sync(key)
            return f"{key}: {value}"
        else:
            all_values = self.blackboard.read_all_sync()
            return str(all_values)
    
    async def _write_blackboard(self, inputs: Dict) -> str:
        """Write to blackboard"""
        key = inputs.get("key")
        value = inputs.get("value")
        if key and value is not None:
            self.blackboard.write_sync(key, value, self.agent_id)
            return f"Written {key}={value}"
        return "Missing key or value"
    
    async def _check_goal(self, inputs: Dict) -> str:
        """Check goal alignment"""
        goal_id = self.blackboard.read_sync("goal_id")
        if goal_id:
            current_action = inputs.get("action", "")
            alignment = self.goal_tree.check_alignment(goal_id, current_action)
            return str(alignment)
        return "No goal set"
    
    # =========================================================================
    # SHARED CONTEXT MANAGEMENT
    # =========================================================================
    
    def _create_shared_context(self):
        """Create shared context for KV-cache sharing"""
        blackboard_state = self.blackboard.read_all_sync()
        goal_id = blackboard_state.get("goal_id")
        goal = self.goal_tree.get_goal(goal_id) if goal_id else None
        
        goal_dict = {
            "description": goal.description if goal else "",
            "success_criteria": goal.success_criteria if goal else [],
        } if goal else {}
        
        context_content = self.llm.build_shared_context_content(
            system_prompt=self.config.system_prompt,
            task_description=blackboard_state.get("task", ""),
            goal=goal_dict,
            blackboard_state=blackboard_state,
            available_tools=self.tools.list_tools(),
        )
        
        self.llm.create_shared_context(self.context_id, context_content)
    
    def update_shared_context(self):
        """Update shared context when blackboard changes"""
        self._create_shared_context()
    
    # =========================================================================
    # MULTI-AGENT COORDINATION
    # =========================================================================
    
    async def spawn_sub_agent(
        self,
        task: str,
        agent_type: str = "worker",
    ) -> 'SadhakaAgent':
        """Spawn a sub-agent for parallel work"""
        sub_agent = SadhakaAgent(
            agent_id=f"{self.agent_id}_sub_{uuid.uuid4().hex[:4]}",
            config=self.config,
            llm=self.llm,  # Share LLM for KV-cache sharing
            milvus=self.milvus,  # Share Milvus
        )
        
        # Share blackboard
        sub_agent.blackboard = self.blackboard
        sub_agent.current_task_id = self.current_task_id
        sub_agent.context_id = self.context_id  # Share context for KV-cache
        
        return sub_agent
    
    async def run_parallel(
        self,
        tasks: List[Dict],
    ) -> List[Dict]:
        """
        Run multiple tasks in parallel with KV-cache sharing.
        
        All agents share the same context, massive token savings.
        """
        # Prepare agent prompts
        agent_prompts = [
            {"agent_id": f"worker_{i}", "prompt": t["task"]}
            for i, t in enumerate(tasks)
        ]
        
        # Generate all at once with shared context
        results = self.llm.generate_multi_agent(
            context_id=self.context_id,
            agent_prompts=agent_prompts,
        )
        
        return [
            {"task": t["task"], "result": r.text, "agent_id": r.agent_id}
            for t, r in zip(tasks, results)
        ]
    
    # =========================================================================
    # STATS AND DIAGNOSTICS
    # =========================================================================
    
    def get_stats(self) -> Dict:
        """Get agent statistics"""
        return {
            "agent_id": self.agent_id,
            "current_task": self.current_task_id,
            "history_length": len(self.history),
            "tools_count": len(self.tools.tools),
            "kv_cache_stats": self.llm.get_cache_stats(),
            "recovery_stats": self.recovery.get_stats(),
            "docker_stats": self.docker.get_stats(),
            "milvus_stats": self.milvus.get_stats(),
        }


# =========================================================================
# CLI INTERFACE
# =========================================================================

async def main():
    """CLI entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Sadhaka Agent")
    parser.add_argument("task", nargs="?", help="Task to execute")
    parser.add_argument("--model", default="Qwen/Qwen2.5-7B-Instruct", help="Model name")
    parser.add_argument("--interactive", "-i", action="store_true", help="Interactive mode")
    
    args = parser.parse_args()
    
    # Create agent
    config = DEFAULT_CONFIG
    config.vllm.model = args.model
    
    agent = SadhakaAgent(config=config)
    
    if args.interactive:
        print("Sadhaka Agent - Interactive Mode")
        print("Type 'quit' to exit, 'stats' for statistics\n")
        
        while True:
            try:
                task = input("Task> ").strip()
                if task.lower() == "quit":
                    break
                elif task.lower() == "stats":
                    print(agent.get_stats())
                elif task:
                    result = await agent.run(task)
                    print(f"\nResult: {result}\n")
            except KeyboardInterrupt:
                break
    elif args.task:
        result = await agent.run(args.task)
        print(result)
    else:
        parser.print_help()


if __name__ == "__main__":
    asyncio.run(main())
