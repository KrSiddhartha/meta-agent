"""
Sadhaka Tracing - Structured logging and execution traces

Addresses ChatGPT review concern: "Hard to debug without per-step logs"
"""

import time
import json
import logging
from typing import Optional, Dict, List, Any
from dataclasses import dataclass, field, asdict
from enum import Enum

logger = logging.getLogger(__name__)


class TraceEventType(Enum):
    TASK_START = "task_start"
    TASK_END = "task_end"
    THOUGHT = "thought"
    ACTION_START = "action_start"
    ACTION_END = "action_end"
    TOOL_CALL = "tool_call"
    TOOL_RESULT = "tool_result"
    LLM_REQUEST = "llm_request"
    LLM_RESPONSE = "llm_response"
    ERROR = "error"
    RECOVERY = "recovery"
    GOAL_UPDATE = "goal_update"
    BLACKBOARD_WRITE = "blackboard_write"


@dataclass
class TraceEvent:
    """Single trace event"""
    event_type: TraceEventType
    timestamp: float
    agent_id: str
    task_id: str
    iteration: int = 0
    data: Dict[str, Any] = field(default_factory=dict)
    duration_ms: Optional[float] = None
    parent_event_id: Optional[str] = None
    
    def to_dict(self) -> Dict:
        d = asdict(self)
        d["event_type"] = self.event_type.value
        return d


@dataclass
class ExecutionTrace:
    """Complete execution trace for a task"""
    task_id: str
    agent_id: str
    start_time: float
    events: List[TraceEvent] = field(default_factory=list)
    end_time: Optional[float] = None
    success: Optional[bool] = None
    
    # Aggregated metrics
    total_llm_calls: int = 0
    total_llm_tokens: int = 0
    total_tool_calls: int = 0
    total_errors: int = 0
    
    def add_event(self, event: TraceEvent):
        """Add event and update metrics"""
        self.events.append(event)
        
        if event.event_type == TraceEventType.LLM_RESPONSE:
            self.total_llm_calls += 1
            self.total_llm_tokens += event.data.get("tokens", 0)
        elif event.event_type == TraceEventType.TOOL_RESULT:
            self.total_tool_calls += 1
        elif event.event_type == TraceEventType.ERROR:
            self.total_errors += 1
    
    def get_summary(self) -> Dict:
        """Get execution summary"""
        duration = (self.end_time or time.time()) - self.start_time
        return {
            "task_id": self.task_id,
            "agent_id": self.agent_id,
            "duration_seconds": round(duration, 2),
            "success": self.success,
            "total_events": len(self.events),
            "llm_calls": self.total_llm_calls,
            "llm_tokens": self.total_llm_tokens,
            "tool_calls": self.total_tool_calls,
            "errors": self.total_errors,
            "avg_iteration_time_ms": round(duration * 1000 / max(1, self.total_llm_calls), 1),
        }
    
    def get_timeline(self) -> List[Dict]:
        """Get simplified timeline view"""
        return [
            {
                "time": round(e.timestamp - self.start_time, 3),
                "type": e.event_type.value,
                "iteration": e.iteration,
                "summary": self._summarize_event(e),
            }
            for e in self.events
        ]
    
    def _summarize_event(self, event: TraceEvent) -> str:
        """Create one-line summary of event"""
        if event.event_type == TraceEventType.THOUGHT:
            thought = event.data.get("thought", "")[:50]
            return f'"{thought}..."' if len(event.data.get("thought", "")) > 50 else f'"{thought}"'
        elif event.event_type == TraceEventType.TOOL_CALL:
            return f'{event.data.get("tool")}({event.data.get("input", "")[:30]}...)'
        elif event.event_type == TraceEventType.TOOL_RESULT:
            success = "✓" if event.data.get("success") else "✗"
            return f'{success} {str(event.data.get("result", ""))[:40]}'
        elif event.event_type == TraceEventType.ERROR:
            return event.data.get("message", "Unknown error")[:50]
        elif event.event_type == TraceEventType.LLM_RESPONSE:
            return f'{event.data.get("tokens", 0)} tokens, {event.duration_ms:.0f}ms'
        else:
            return str(event.data)[:50]
    
    def to_json(self) -> str:
        """Export full trace as JSON"""
        return json.dumps({
            "summary": self.get_summary(),
            "timeline": self.get_timeline(),
            "events": [e.to_dict() for e in self.events],
        }, indent=2, default=str)


class Tracer:
    """
    Execution tracer for debugging and observability.
    
    Usage:
        tracer = Tracer()
        trace = tracer.start_trace("task_123", "agent_1")
        
        tracer.record_thought(trace, 1, "I need to calculate...")
        tracer.record_tool_call(trace, 1, "calculator", {"expression": "2+2"})
        tracer.record_tool_result(trace, 1, {"success": True, "result": 4})
        
        tracer.end_trace(trace, success=True)
        print(trace.get_summary())
    """
    
    def __init__(self, persist_traces: bool = False, milvus_client=None):
        self.persist = persist_traces
        self.milvus = milvus_client
        self.active_traces: Dict[str, ExecutionTrace] = {}
    
    def start_trace(self, task_id: str, agent_id: str) -> ExecutionTrace:
        """Start a new execution trace"""
        trace = ExecutionTrace(
            task_id=task_id,
            agent_id=agent_id,
            start_time=time.time(),
        )
        
        trace.add_event(TraceEvent(
            event_type=TraceEventType.TASK_START,
            timestamp=time.time(),
            agent_id=agent_id,
            task_id=task_id,
            data={"task_id": task_id},
        ))
        
        self.active_traces[task_id] = trace
        logger.info(f"[TRACE] Started trace for task {task_id}")
        return trace
    
    def end_trace(self, trace: ExecutionTrace, success: bool, result: Any = None):
        """End an execution trace"""
        trace.end_time = time.time()
        trace.success = success
        
        trace.add_event(TraceEvent(
            event_type=TraceEventType.TASK_END,
            timestamp=time.time(),
            agent_id=trace.agent_id,
            task_id=trace.task_id,
            data={"success": success, "result": str(result)[:200] if result else None},
        ))
        
        summary = trace.get_summary()
        logger.info(f"[TRACE] Ended task {trace.task_id}: {summary}")
        
        if self.persist and self.milvus:
            self._persist_trace(trace)
        
        self.active_traces.pop(trace.task_id, None)
    
    def record_thought(self, trace: ExecutionTrace, iteration: int, thought: str):
        """Record agent thought"""
        trace.add_event(TraceEvent(
            event_type=TraceEventType.THOUGHT,
            timestamp=time.time(),
            agent_id=trace.agent_id,
            task_id=trace.task_id,
            iteration=iteration,
            data={"thought": thought},
        ))
        logger.debug(f"[TRACE] Iteration {iteration} thought: {thought[:100]}...")
    
    def record_tool_call(self, trace: ExecutionTrace, iteration: int, tool: str, input_data: Any):
        """Record tool invocation"""
        trace.add_event(TraceEvent(
            event_type=TraceEventType.TOOL_CALL,
            timestamp=time.time(),
            agent_id=trace.agent_id,
            task_id=trace.task_id,
            iteration=iteration,
            data={"tool": tool, "input": str(input_data)[:500]},
        ))
        logger.debug(f"[TRACE] Iteration {iteration} tool call: {tool}")
    
    def record_tool_result(
        self, 
        trace: ExecutionTrace, 
        iteration: int, 
        result: Any, 
        duration_ms: float = 0
    ):
        """Record tool result"""
        success = result.get("success", True) if isinstance(result, dict) else True
        trace.add_event(TraceEvent(
            event_type=TraceEventType.TOOL_RESULT,
            timestamp=time.time(),
            agent_id=trace.agent_id,
            task_id=trace.task_id,
            iteration=iteration,
            duration_ms=duration_ms,
            data={"success": success, "result": str(result)[:500]},
        ))
        logger.debug(f"[TRACE] Iteration {iteration} tool result: {success}")
    
    def record_llm_call(
        self, 
        trace: ExecutionTrace, 
        iteration: int, 
        prompt_tokens: int,
        completion_tokens: int,
        duration_ms: float,
        kv_cache_hit: bool = False,
    ):
        """Record LLM call metrics"""
        trace.add_event(TraceEvent(
            event_type=TraceEventType.LLM_RESPONSE,
            timestamp=time.time(),
            agent_id=trace.agent_id,
            task_id=trace.task_id,
            iteration=iteration,
            duration_ms=duration_ms,
            data={
                "tokens": prompt_tokens + completion_tokens,
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "kv_cache_hit": kv_cache_hit,
            },
        ))
        logger.debug(f"[TRACE] LLM call: {prompt_tokens}+{completion_tokens} tokens, {duration_ms:.0f}ms")
    
    def record_error(
        self, 
        trace: ExecutionTrace, 
        iteration: int, 
        error_type: str, 
        message: str,
        recoverable: bool = True,
    ):
        """Record error"""
        trace.add_event(TraceEvent(
            event_type=TraceEventType.ERROR,
            timestamp=time.time(),
            agent_id=trace.agent_id,
            task_id=trace.task_id,
            iteration=iteration,
            data={
                "error_type": error_type,
                "message": message,
                "recoverable": recoverable,
            },
        ))
        logger.warning(f"[TRACE] Error at iteration {iteration}: {error_type}: {message}")
    
    def record_recovery(
        self, 
        trace: ExecutionTrace, 
        iteration: int, 
        action: str,
        attempt: int,
    ):
        """Record recovery attempt"""
        trace.add_event(TraceEvent(
            event_type=TraceEventType.RECOVERY,
            timestamp=time.time(),
            agent_id=trace.agent_id,
            task_id=trace.task_id,
            iteration=iteration,
            data={"action": action, "attempt": attempt},
        ))
        logger.info(f"[TRACE] Recovery attempt {attempt}: {action}")
    
    def _persist_trace(self, trace: ExecutionTrace):
        """Save trace to Milvus"""
        if not self.milvus:
            return
        
        self.milvus.insert("traces", {
            "id": f"trace_{trace.task_id}",
            "task_id": trace.task_id,
            "agent_id": trace.agent_id,
            "start_time": int(trace.start_time),
            "end_time": int(trace.end_time or 0),
            "success": trace.success,
            "summary_json": json.dumps(trace.get_summary()),
            "events_json": json.dumps([e.to_dict() for e in trace.events]),
        })
    
    def get_active_trace(self, task_id: str) -> Optional[ExecutionTrace]:
        """Get active trace by task ID"""
        return self.active_traces.get(task_id)


# Singleton tracer instance
_default_tracer: Optional[Tracer] = None

def get_tracer() -> Tracer:
    """Get default tracer instance"""
    global _default_tracer
    if _default_tracer is None:
        _default_tracer = Tracer()
    return _default_tracer
