"""
Sadhaka Test Suite - Comprehensive tests for all components
"""

import asyncio
import time
import json
import sys
import os
import importlib.util

# Get the sadhaka directory
SADHAKA_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def load_module(name, path):
    """Load a module directly from file path"""
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

# Load modules directly to avoid relative import issues
config_mod = load_module("config", os.path.join(SADHAKA_DIR, "config.py"))
SadhakaConfig = config_mod.SadhakaConfig
DEFAULT_CONFIG = config_mod.DEFAULT_CONFIG

vllm_mod = load_module("vllm_provider", os.path.join(SADHAKA_DIR, "llm", "vllm_provider.py"))
VLLMLatentProvider = vllm_mod.VLLMLatentProvider
MockLLM = vllm_mod.MockLLM

# Load schemas first since milvus_client depends on it
schemas_mod = load_module("schemas", os.path.join(SADHAKA_DIR, "memory", "schemas.py"))

milvus_mod = load_module("milvus_client", os.path.join(SADHAKA_DIR, "memory", "milvus_client.py"))
MilvusClient = milvus_mod.MilvusClient

health_mod = load_module("health_manager", os.path.join(SADHAKA_DIR, "memory", "health_manager.py"))
HealthManager = health_mod.HealthManager
EntityType = health_mod.EntityType
HealthUpdate = health_mod.HealthUpdate

blackboard_mod = load_module("blackboard", os.path.join(SADHAKA_DIR, "orchestration", "blackboard.py"))
Blackboard = blackboard_mod.Blackboard

docker_mod = load_module("docker_manager", os.path.join(SADHAKA_DIR, "runtime", "docker_manager.py"))
DockerManager = docker_mod.DockerManager
ContainerSpec = docker_mod.ContainerSpec
ContainerLifecycle = docker_mod.ContainerLifecycle

goal_mod = load_module("goal_tree", os.path.join(SADHAKA_DIR, "goals", "goal_tree.py"))
GoalTree = goal_mod.GoalTree
GoalStatus = goal_mod.GoalStatus

recovery_mod = load_module("recovery_engine", os.path.join(SADHAKA_DIR, "recovery", "recovery_engine.py"))
RecoveryEngine = recovery_mod.RecoveryEngine
FailureType = recovery_mod.FailureType

parser_mod = load_module("parser", os.path.join(SADHAKA_DIR, "core", "parser.py"))
ReActParser = parser_mod.ReActParser

tools_mod = load_module("tools", os.path.join(SADHAKA_DIR, "core", "tools.py"))
ToolRegistry = tools_mod.ToolRegistry


class TestResults:
    """Collect test results"""
    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.errors = []
    
    def record(self, name: str, passed: bool, error: str = None):
        if passed:
            self.passed += 1
            print(f"  ✓ {name}")
        else:
            self.failed += 1
            self.errors.append((name, error))
            print(f"  ✗ {name}: {error}")
    
    def summary(self):
        total = self.passed + self.failed
        print(f"\n{'='*60}")
        print(f"Results: {self.passed}/{total} passed")
        if self.errors:
            print(f"\nFailures:")
            for name, error in self.errors:
                print(f"  - {name}: {error}")
        return self.failed == 0


results = TestResults()


# =============================================================================
# VLLM PROVIDER TESTS
# =============================================================================

def test_vllm_provider():
    print("\n[VLLMLatentProvider Tests]")
    
    # Test initialization (mock mode)
    try:
        provider = VLLMLatentProvider(model="test-model")
        results.record("Provider initialization", True)
    except Exception as e:
        results.record("Provider initialization", False, str(e))
        return
    
    # Test shared context creation
    try:
        ctx = provider.create_shared_context(
            context_id="test_ctx",
            content="System prompt for testing",
            warm_cache=False,
        )
        assert ctx.id == "test_ctx"
        assert ctx.token_count > 0
        results.record("Shared context creation", True)
    except Exception as e:
        results.record("Shared context creation", False, str(e))
    
    # Test single generation
    try:
        result = provider.generate(
            prompt="What is 2+2?",
            agent_id="test_agent",
            context_id="test_ctx",
        )
        assert result.agent_id == "test_agent"
        assert result.kv_cache_hit == True
        assert len(result.text) > 0
        results.record("Single generation", True)
    except Exception as e:
        results.record("Single generation", False, str(e))
    
    # Test multi-agent generation
    try:
        prompts = [
            {"agent_id": "agent1", "prompt": "Task 1"},
            {"agent_id": "agent2", "prompt": "Task 2"},
            {"agent_id": "agent3", "prompt": "Task 3"},
        ]
        multi_results = provider.generate_multi_agent("test_ctx", prompts)
        assert len(multi_results) == 3
        assert all(r.kv_cache_hit for r in multi_results)
        results.record("Multi-agent generation", True)
    except Exception as e:
        results.record("Multi-agent generation", False, str(e))
    
    # Test cache stats
    try:
        stats = provider.get_cache_stats()
        assert "shared_contexts" in stats
        assert stats["shared_contexts"] >= 1
        assert stats["total_context_accesses"] >= 4  # 1 single + 3 multi
        results.record("Cache statistics", True)
    except Exception as e:
        results.record("Cache statistics", False, str(e))


# =============================================================================
# MILVUS CLIENT TESTS
# =============================================================================

def test_milvus_client():
    print("\n[MilvusClient Tests]")
    
    # Test initialization (mock mode)
    try:
        client = MilvusClient(uri="http://localhost:19530")
        results.record("Client initialization", True)
    except Exception as e:
        results.record("Client initialization", False, str(e))
        return
    
    # Test collection operations
    try:
        client.ensure_collection("test_collection")
        assert "test_collection" in client.list_collections()
        results.record("Collection creation", True)
    except Exception as e:
        results.record("Collection creation", False, str(e))
    
    # Test CRUD operations
    try:
        # Insert
        record_id = client.insert("test_collection", {
            "id": "test_1",
            "name": "Test Record",
            "value": 42,
        })
        assert record_id == "test_1"
        
        # Get
        record = client.get("test_collection", "test_1")
        assert record["name"] == "Test Record"
        
        # Update
        client.update("test_collection", "test_1", {"value": 100})
        record = client.get("test_collection", "test_1")
        assert record["value"] == 100
        
        # Delete
        client.delete("test_collection", "test_1")
        record = client.get("test_collection", "test_1")
        assert record is None
        
        results.record("CRUD operations", True)
    except Exception as e:
        results.record("CRUD operations", False, str(e))
    
    # Test query
    try:
        for i in range(5):
            client.insert("test_collection", {
                "id": f"q_{i}",
                "health_score": 0.5 + i * 0.1,
            })
        
        healthy = client.query("test_collection", "health_score >= 0.7")
        assert len(healthy) >= 2
        results.record("Query operations", True)
    except Exception as e:
        results.record("Query operations", False, str(e))


# =============================================================================
# HEALTH MANAGER TESTS
# =============================================================================

def test_health_manager():
    print("\n[HealthManager Tests]")
    
    client = MilvusClient()
    health = HealthManager(client)
    
    # Create test tool
    client.insert("tools", {
        "id": "tool_test_v1",
        "name": "test_tool",
        "health_score": 1.0,
        "health_status": "healthy",
        "total_executions": 0,
        "successful_executions": 0,
        "failed_executions": 0,
        "consecutive_failures": 0,
        "avg_execution_time_ms": 0,
        "last_execution_at": 0,
    })
    
    # Test successful execution recording
    try:
        result = health.record_execution(
            EntityType.TOOL,
            "tool_test_v1",
            HealthUpdate(success=True, execution_time_ms=100),
        )
        assert result["health_score"] > 0.9
        assert result["health_status"] == "healthy"
        results.record("Successful execution recording", True)
    except Exception as e:
        results.record("Successful execution recording", False, str(e))
    
    # Test failed execution recording
    try:
        for _ in range(3):
            result = health.record_execution(
                EntityType.TOOL,
                "tool_test_v1",
                HealthUpdate(success=False, execution_time_ms=50, error_type="test_error"),
            )
        assert result["consecutive_failures"] == 3
        assert result["health_score"] < 0.8
        results.record("Failed execution recording", True)
    except Exception as e:
        results.record("Failed execution recording", False, str(e))
    
    # Test health check
    try:
        summary = health.run_health_check(EntityType.TOOL)
        assert "total" in summary
        results.record("Health check", True)
    except Exception as e:
        results.record("Health check", False, str(e))


# =============================================================================
# BLACKBOARD TESTS
# =============================================================================

def test_blackboard():
    print("\n[Blackboard Tests]")
    
    client = MilvusClient()
    blackboard = Blackboard(client, "test_task_123")
    
    # Test synchronous write/read
    try:
        entry = blackboard.write_sync("key1", "value1", "agent1")
        assert entry.key == "key1"
        assert entry.value == "value1"
        assert entry.version == 1
        
        value = blackboard.read_sync("key1")
        assert value == "value1"
        results.record("Sync write/read", True)
    except Exception as e:
        results.record("Sync write/read", False, str(e))
    
    # Test version increment
    try:
        blackboard.write_sync("key1", "value2", "agent2")
        entry = blackboard._local_cache["key1"]
        assert entry.version == 2
        assert entry.written_by == "agent2"
        results.record("Version tracking", True)
    except Exception as e:
        results.record("Version tracking", False, str(e))
    
    # Test read all
    try:
        blackboard.write_sync("key2", {"nested": "data"}, "agent1")
        all_data = blackboard.read_all_sync()
        assert "key1" in all_data
        assert "key2" in all_data
        assert all_data["key2"]["nested"] == "data"
        results.record("Read all", True)
    except Exception as e:
        results.record("Read all", False, str(e))
    
    # Test contributors
    try:
        contributors = blackboard.get_contributors()
        assert "agent1" in contributors
        assert "agent2" in contributors
        results.record("Contributors tracking", True)
    except Exception as e:
        results.record("Contributors tracking", False, str(e))


# =============================================================================
# DOCKER MANAGER TESTS
# =============================================================================

def test_docker_manager():
    print("\n[DockerManager Tests]")
    
    docker = DockerManager("/tmp/sadhaka_test")
    
    # Test initialization
    try:
        assert docker.workspace.exists()
        results.record("Workspace creation", True)
    except Exception as e:
        results.record("Workspace creation", False, str(e))
    
    # Test ephemeral execution (subprocess fallback)
    try:
        code = '''
print("Hello from Sadhaka!")
x = 2 + 2
print(f"2 + 2 = {x}")
'''
        result = asyncio.run(docker.run_ephemeral(code))
        assert result.success
        assert "Hello from Sadhaka!" in result.stdout
        assert "2 + 2 = 4" in result.stdout
        results.record("Ephemeral execution", True)
    except Exception as e:
        results.record("Ephemeral execution", False, str(e))
    
    # Test error handling
    try:
        bad_code = '''
raise ValueError("Intentional error")
'''
        result = asyncio.run(docker.run_ephemeral(bad_code))
        assert not result.success
        assert result.exit_code != 0
        results.record("Error handling", True)
    except Exception as e:
        results.record("Error handling", False, str(e))
    
    # Test stats
    try:
        stats = docker.get_stats()
        assert "docker_available" in stats
        assert "workspace" in stats
        results.record("Stats retrieval", True)
    except Exception as e:
        results.record("Stats retrieval", False, str(e))


# =============================================================================
# GOAL TREE TESTS
# =============================================================================

def test_goal_tree():
    print("\n[GoalTree Tests]")
    
    tree = GoalTree()
    
    # Test root goal creation
    try:
        root = tree.create_root_goal(
            task_id="task_1",
            description="Complete the data analysis",
            success_criteria=["Extract data", "Calculate statistics", "Generate report"],
        )
        assert root.status == GoalStatus.ACTIVE
        assert root.progress == 0.0
        results.record("Root goal creation", True)
    except Exception as e:
        results.record("Root goal creation", False, str(e))
    
    # Test goal decomposition
    try:
        children = tree.decompose_goal(root.id, [
            {"description": "Extract data from CSV", "success_criteria": ["File parsed", "Data validated"]},
            {"description": "Calculate statistics", "success_criteria": ["Mean computed", "Std computed"]},
            {"description": "Generate report", "success_criteria": ["PDF created"]},
        ])
        assert len(children) == 3
        assert len(root.children_ids) == 3
        results.record("Goal decomposition", True)
    except Exception as e:
        results.record("Goal decomposition", False, str(e))
    
    # Test progress tracking
    try:
        tree.update_progress(children[0].id, 1.0)
        tree.update_progress(children[1].id, 0.5)
        
        root = tree.get_goal(root.id)
        assert root.progress > 0
        assert root.progress < 1.0
        results.record("Progress tracking", True)
    except Exception as e:
        results.record("Progress tracking", False, str(e))
    
    # Test goal completion
    try:
        for child in children:
            tree.complete_goal(child.id)
        
        root = tree.get_goal(root.id)
        assert root.status == GoalStatus.COMPLETED
        assert root.progress == 1.0
        results.record("Goal completion", True)
    except Exception as e:
        results.record("Goal completion", False, str(e))
    
    # Test alignment check
    try:
        new_goal = tree.create_root_goal(
            task_id="task_2",
            description="Analyze sales data",
            success_criteria=["Load sales.csv", "Compute totals"],
        )
        
        alignment = tree.check_alignment(new_goal.id, "Loading sales data from file")
        assert "aligned" in alignment
        assert "score" in alignment
        results.record("Alignment check", True)
    except Exception as e:
        results.record("Alignment check", False, str(e))


# =============================================================================
# RECOVERY ENGINE TESTS
# =============================================================================

def test_recovery_engine():
    print("\n[RecoveryEngine Tests]")
    
    engine = RecoveryEngine()
    
    # Test circuit breaker
    try:
        cb = engine.get_circuit_breaker("test_service")
        assert cb.state == "CLOSED"
        assert cb.can_execute()
        
        # Simulate failures
        for _ in range(5):
            cb.record_failure()
        
        assert cb.state == "OPEN"
        assert not cb.can_execute()
        
        cb.record_success()
        assert cb.state == "CLOSED"
        results.record("Circuit breaker", True)
    except Exception as e:
        results.record("Circuit breaker", False, str(e))
    
    # Test execute with recovery (success)
    try:
        call_count = [0]
        def successful_func():
            call_count[0] += 1
            return "success"
        
        result = asyncio.run(engine.execute_with_recovery(
            successful_func,
            service_name="success_service",
        ))
        assert result == "success"
        assert call_count[0] == 1
        results.record("Successful execution", True)
    except Exception as e:
        results.record("Successful execution", False, str(e))
    
    # Test execute with recovery (retry then success)
    try:
        attempt = [0]
        def flaky_func():
            attempt[0] += 1
            if attempt[0] < 2:
                raise ValueError("Temporary failure")
            return "recovered"
        
        result = asyncio.run(engine.execute_with_recovery(
            flaky_func,
            service_name="flaky_service",
            failure_type=FailureType.TOOL_ERROR,
        ))
        assert result == "recovered"
        assert attempt[0] == 2
        results.record("Retry then success", True)
    except Exception as e:
        results.record("Retry then success", False, str(e))
    
    # Test checkpointing
    try:
        checkpoint_id = engine.save_checkpoint("task_123", {"step": 5, "data": [1, 2, 3]})
        assert checkpoint_id.startswith("cp_task_123")
        
        checkpoint = engine.get_checkpoint("task_123")
        assert checkpoint["state"]["step"] == 5
        
        engine.clear_checkpoint("task_123")
        assert engine.get_checkpoint("task_123") is None
        results.record("Checkpointing", True)
    except Exception as e:
        results.record("Checkpointing", False, str(e))
    
    # Test diagnostics
    try:
        diag = engine.get_diagnostics()
        assert "total_failures" in diag
        assert "circuit_breakers" in diag
        results.record("Diagnostics", True)
    except Exception as e:
        results.record("Diagnostics", False, str(e))


# =============================================================================
# PARSER TESTS
# =============================================================================

def test_parser():
    print("\n[ReActParser Tests]")
    
    parser = ReActParser()
    
    # Test standard ReAct format
    try:
        text = """Thought: I need to calculate the sum.
Action: calculator
Action Input: {"expression": "2 + 2"}"""
        
        parsed = parser.parse(text)
        assert parsed.thought == "I need to calculate the sum."
        assert parsed.action == "calculator"
        assert parsed.action_input["expression"] == "2 + 2"
        assert parsed.final_answer is None
        results.record("Standard ReAct parsing", True)
    except Exception as e:
        results.record("Standard ReAct parsing", False, str(e))
    
    # Test final answer
    try:
        text = """Thought: I have computed the result.
Final Answer: The answer is 42."""
        
        parsed = parser.parse(text)
        assert "computed" in parsed.thought
        assert parsed.action is None
        assert parsed.final_answer == "The answer is 42."
        results.record("Final answer parsing", True)
    except Exception as e:
        results.record("Final answer parsing", False, str(e))
    
    # Test JSON format
    try:
        text = '{"thought": "Testing JSON", "action": "test", "action_input": {"key": "value"}}'
        
        parsed = parser.parse(text)
        assert parsed.thought == "Testing JSON"
        assert parsed.action == "test"
        results.record("JSON format parsing", True)
    except Exception as e:
        results.record("JSON format parsing", False, str(e))
    
    # Test observation formatting
    try:
        obs = parser.format_observation({"result": 42, "success": True})
        assert "Observation:" in obs
        assert "42" in obs
        results.record("Observation formatting", True)
    except Exception as e:
        results.record("Observation formatting", False, str(e))


# =============================================================================
# TOOL REGISTRY TESTS
# =============================================================================

def test_tools():
    print("\n[ToolRegistry Tests]")
    
    registry = ToolRegistry()
    
    # Test built-in tools exist
    try:
        assert "calculator" in registry.tools
        assert "json_parser" in registry.tools
        assert "string_ops" in registry.tools
        results.record("Built-in tools exist", True)
    except Exception as e:
        results.record("Built-in tools exist", False, str(e))
    
    # Test calculator
    try:
        result = registry.execute("calculator", expression="2 + 2 * 3")
        assert result["success"]
        assert result["result"] == 8
        
        result = registry.execute("calculator", expression="sqrt(16)")
        assert result["success"]
        assert result["result"] == 4
        results.record("Calculator tool", True)
    except Exception as e:
        results.record("Calculator tool", False, str(e))
    
    # Test JSON parser
    try:
        result = registry.execute("json_parser", 
            json_string='{"name": "test", "values": [1, 2, 3]}',
            path="values.1"
        )
        assert result["success"]
        assert result["extracted"] == 2
        results.record("JSON parser tool", True)
    except Exception as e:
        results.record("JSON parser tool", False, str(e))
    
    # Test string ops
    try:
        result = registry.execute("string_ops", operation="upper", text="hello")
        assert result["success"]
        assert result["result"] == "HELLO"
        
        result = registry.execute("string_ops", operation="split", text="a,b,c", arg1=",")
        assert result["success"]
        assert result["result"] == ["a", "b", "c"]
        results.record("String ops tool", True)
    except Exception as e:
        results.record("String ops tool", False, str(e))
    
    # Test custom tool creation
    try:
        registry.create_tool(
            name="custom_adder",
            description="Add two numbers",
            source_code="result = a + b",
            input_schema={"type": "object", "properties": {"a": {"type": "number"}, "b": {"type": "number"}}},
            created_by="test",
        )
        
        result = registry.execute("custom_adder", a=10, b=20)
        assert result == 30 or result.get("result") == 30 or result == {"executed": True}
        results.record("Custom tool creation", True)
    except Exception as e:
        results.record("Custom tool creation", False, str(e))
    
    # Test code validation
    try:
        is_safe, error = registry.validate_code("import os\nos.system('rm -rf /')")
        assert not is_safe
        assert "Dangerous" in error or "Unsafe" in error
        results.record("Code validation (unsafe)", True)
    except Exception as e:
        results.record("Code validation (unsafe)", False, str(e))
    
    try:
        is_safe, error = registry.validate_code("import math\nresult = math.sqrt(16)")
        assert is_safe
        results.record("Code validation (safe)", True)
    except Exception as e:
        results.record("Code validation (safe)", False, str(e))


# =============================================================================
# INTEGRATION TEST
# =============================================================================

def test_integration():
    print("\n[Integration Tests]")
    
    try:
        # Create all components
        llm = VLLMLatentProvider(model="test")
        milvus = MilvusClient()
        tools = ToolRegistry(milvus)
        health = HealthManager(milvus)
        recovery = RecoveryEngine(milvus)
        docker = DockerManager("/tmp/sadhaka_int_test")
        goal_tree = GoalTree(milvus)
        
        # Create shared context
        ctx = llm.create_shared_context(
            "integration_ctx",
            "System prompt for integration test"
        )
        
        # Create goal
        goal = goal_tree.create_root_goal(
            task_id="int_test",
            description="Integration test task",
            success_criteria=["All components work"],
        )
        
        # Create blackboard
        blackboard = Blackboard(milvus, "int_test")
        blackboard.write_sync("goal_id", goal.id, "test_agent")
        blackboard.write_sync("status", "running", "test_agent")
        
        # Use tools
        calc_result = tools.execute("calculator", expression="10 * 5")
        blackboard.write_sync("calc_result", calc_result, "test_agent")
        
        # Record health
        health.record_execution(
            EntityType.TOOL,
            "tool_calculator_v1",
            HealthUpdate(success=True, execution_time_ms=10),
        )
        
        # Run code
        code = "print('Integration test passed!')"
        exec_result = asyncio.run(docker.run_ephemeral(code))
        
        # Complete goal
        goal_tree.complete_goal(goal.id)
        
        # Verify
        final_goal = goal_tree.get_goal(goal.id)
        assert final_goal.status == GoalStatus.COMPLETED
        assert exec_result.success
        assert calc_result["result"] == 50
        
        results.record("Full integration", True)
    except Exception as e:
        results.record("Full integration", False, str(e))


# =============================================================================
# RUN ALL TESTS
# =============================================================================

def main():
    print("=" * 60)
    print("SADHAKA TEST SUITE")
    print("=" * 60)
    
    test_vllm_provider()
    test_milvus_client()
    test_health_manager()
    test_blackboard()
    test_docker_manager()
    test_goal_tree()
    test_recovery_engine()
    test_parser()
    test_tools()
    test_integration()
    
    success = results.summary()
    print("=" * 60)
    
    return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())
