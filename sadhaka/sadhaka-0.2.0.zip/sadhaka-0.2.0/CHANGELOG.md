# Changelog

All notable changes to Sadhaka will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2024-12-06

### Added
- **Tracing module** (`core/tracing.py`)
  - Structured execution traces with timeline view
  - Per-step event recording (thoughts, tool calls, LLM responses)
  - Token and timing metrics
  - JSON export for debugging

- **Safety guards** (`core/safety.py`)
  - Loop detection: blocks repeated identical tool calls
  - Cycle detection: identifies A→B→A→B patterns
  - Max total calls limit
  - Dangerous pattern blocking (rm -rf, eval, etc.)
  - Resource tracking for cleanup (processes, files, containers)
  - Output length validation

- **pyproject.toml** for modern Python packaging

### Changed
- Improved JSON parsing in ReActParser to handle nested objects
- Better error messages throughout

### Fixed
- JSON format parsing for nested action_input objects

## [0.1.0] - 2024-12-06

### Added
- Initial release implementing the 4 Pillars architecture

- **Pillar 1: Durable Memory**
  - MilvusClient with in-memory fallback
  - Blackboard pattern for agent coordination
  - Health score tracking with auto-deprecation

- **Pillar 2: Explicit Tools**
  - ToolRegistry with Pydantic validation
  - Built-in tools: calculator, json_parser, string_ops
  - AST-based code safety validation
  - Dynamic tool creation at runtime

- **Pillar 3: Specific Goal Definition**
  - GoalTree with hierarchical decomposition
  - Progress tracking that bubbles up
  - Alignment checking

- **Pillar 4: Recovery Logic**
  - RecoveryEngine with exponential backoff
  - Circuit breakers per service
  - Checkpointing for long tasks
  - Diagnostics collection

- **Latent Collaboration**
  - VLLMLatentProvider with KV-cache sharing
  - Multi-agent parallel generation
  - 60-80% token savings for shared contexts

- **Runtime**
  - DockerManager with ephemeral and persistent lifecycles
  - Subprocess fallback when Docker unavailable
  - Health monitoring for persistent containers

- **Core Agent**
  - SadhakaAgent with full ReAct loop
  - Integration of all pillars
  - Sub-agent spawning support

### Test Coverage
- 42/42 tests passing
- All components tested independently
- Full integration test
