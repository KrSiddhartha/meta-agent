"""
Sadhaka Memory Schemas - Milvus Collection Definitions

All entities (tools, agents, MCP servers) have health_score tracking
for lifecycle management.
"""

from typing import Dict, List, Any


# ============================================================================
# TOOLS COLLECTION - With Health Score
# ============================================================================

TOOLS_SCHEMA = {
    "collection_name": "tools",
    "description": "Versioned tool registry with health tracking",
    "fields": [
        {"name": "id", "dtype": "VARCHAR", "max_length": 64, "is_primary": True},
        {"name": "name", "dtype": "VARCHAR", "max_length": 128},
        {"name": "version", "dtype": "INT64"},
        {"name": "version_tag", "dtype": "VARCHAR", "max_length": 32},
        {"name": "description", "dtype": "VARCHAR", "max_length": 2048},
        {"name": "source_code", "dtype": "VARCHAR", "max_length": 65535},
        {"name": "input_schema", "dtype": "VARCHAR", "max_length": 4096},
        {"name": "output_schema", "dtype": "VARCHAR", "max_length": 4096},
        # Health tracking
        {"name": "health_score", "dtype": "FLOAT"},
        {"name": "health_status", "dtype": "VARCHAR", "max_length": 16},
        {"name": "total_executions", "dtype": "INT64"},
        {"name": "successful_executions", "dtype": "INT64"},
        {"name": "failed_executions", "dtype": "INT64"},
        {"name": "avg_execution_time_ms", "dtype": "FLOAT"},
        {"name": "last_execution_at", "dtype": "INT64"},
        {"name": "last_failure_at", "dtype": "INT64"},
        {"name": "consecutive_failures", "dtype": "INT64"},
        {"name": "error_types_json", "dtype": "VARCHAR", "max_length": 2048},
        # Lifecycle
        {"name": "created_at", "dtype": "INT64"},
        {"name": "created_by", "dtype": "VARCHAR", "max_length": 64},
        {"name": "deprecated_at", "dtype": "INT64"},
        {"name": "deprecation_reason", "dtype": "VARCHAR", "max_length": 512},
        {"name": "replaced_by", "dtype": "VARCHAR", "max_length": 64},
        {"name": "parent_version_id", "dtype": "VARCHAR", "max_length": 64},
        # Vector
        {"name": "embedding", "dtype": "FLOAT_VECTOR", "dim": 1024},
    ],
}


# ============================================================================
# AGENTS COLLECTION - With Health Score
# ============================================================================

AGENTS_SCHEMA = {
    "collection_name": "agents",
    "description": "Versioned agent registry with health tracking",
    "fields": [
        {"name": "id", "dtype": "VARCHAR", "max_length": 64, "is_primary": True},
        {"name": "name", "dtype": "VARCHAR", "max_length": 128},
        {"name": "version", "dtype": "INT64"},
        {"name": "agent_type", "dtype": "VARCHAR", "max_length": 32},
        {"name": "system_prompt", "dtype": "VARCHAR", "max_length": 16384},
        {"name": "model_config_json", "dtype": "VARCHAR", "max_length": 2048},
        {"name": "tool_ids_json", "dtype": "VARCHAR", "max_length": 4096},
        {"name": "capability_ids_json", "dtype": "VARCHAR", "max_length": 4096},
        # Health tracking
        {"name": "health_score", "dtype": "FLOAT"},
        {"name": "health_status", "dtype": "VARCHAR", "max_length": 16},
        {"name": "total_tasks", "dtype": "INT64"},
        {"name": "successful_tasks", "dtype": "INT64"},
        {"name": "failed_tasks", "dtype": "INT64"},
        {"name": "avg_task_time_ms", "dtype": "FLOAT"},
        {"name": "last_active_at", "dtype": "INT64"},
        # Hierarchy
        {"name": "parent_agent_id", "dtype": "VARCHAR", "max_length": 64},
        {"name": "spawned_by_task_id", "dtype": "VARCHAR", "max_length": 64},
        # Lifecycle
        {"name": "status", "dtype": "VARCHAR", "max_length": 16},
        {"name": "created_at", "dtype": "INT64"},
        # Vector
        {"name": "embedding", "dtype": "FLOAT_VECTOR", "dim": 1024},
    ],
}


# ============================================================================
# MCP SERVERS COLLECTION - With Health Score
# ============================================================================

MCP_SERVERS_SCHEMA = {
    "collection_name": "mcp_servers",
    "description": "Agent-created MCP servers with health tracking",
    "fields": [
        {"name": "id", "dtype": "VARCHAR", "max_length": 64, "is_primary": True},
        {"name": "name", "dtype": "VARCHAR", "max_length": 128},
        {"name": "version", "dtype": "INT64"},
        {"name": "description", "dtype": "VARCHAR", "max_length": 2048},
        {"name": "transport_type", "dtype": "VARCHAR", "max_length": 16},
        {"name": "container_id", "dtype": "VARCHAR", "max_length": 64},
        {"name": "port", "dtype": "INT64"},
        {"name": "source_code", "dtype": "VARCHAR", "max_length": 65535},
        {"name": "tools_json", "dtype": "VARCHAR", "max_length": 16384},
        # Health tracking
        {"name": "health_score", "dtype": "FLOAT"},
        {"name": "health_status", "dtype": "VARCHAR", "max_length": 16},
        {"name": "uptime_seconds", "dtype": "INT64"},
        {"name": "total_requests", "dtype": "INT64"},
        {"name": "failed_requests", "dtype": "INT64"},
        {"name": "avg_response_time_ms", "dtype": "FLOAT"},
        {"name": "last_health_check", "dtype": "INT64"},
        {"name": "consecutive_failures", "dtype": "INT64"},
        # Lifecycle
        {"name": "runtime_status", "dtype": "VARCHAR", "max_length": 16},
        {"name": "created_at", "dtype": "INT64"},
        {"name": "created_by", "dtype": "VARCHAR", "max_length": 64},
        # Vector
        {"name": "embedding", "dtype": "FLOAT_VECTOR", "dim": 1024},
    ],
}


# ============================================================================
# TASK STATE COLLECTION - Blackboard
# ============================================================================

TASK_STATE_SCHEMA = {
    "collection_name": "task_state",
    "description": "Blackboard for agent communication",
    "fields": [
        {"name": "id", "dtype": "VARCHAR", "max_length": 64, "is_primary": True},
        {"name": "task_id", "dtype": "VARCHAR", "max_length": 64},
        {"name": "goal_id", "dtype": "VARCHAR", "max_length": 64},
        {"name": "status", "dtype": "VARCHAR", "max_length": 16},
        {"name": "current_step", "dtype": "INT64"},
        {"name": "current_phase", "dtype": "VARCHAR", "max_length": 32},
        {"name": "inputs_json", "dtype": "VARCHAR", "max_length": 65535},
        {"name": "outputs_json", "dtype": "VARCHAR", "max_length": 65535},
        {"name": "intermediate_json", "dtype": "VARCHAR", "max_length": 65535},
        {"name": "context_json", "dtype": "VARCHAR", "max_length": 65535},
        {"name": "owner_agent_id", "dtype": "VARCHAR", "max_length": 64},
        {"name": "waiting_for_json", "dtype": "VARCHAR", "max_length": 2048},
        {"name": "contributors_json", "dtype": "VARCHAR", "max_length": 4096},
        {"name": "locks_json", "dtype": "VARCHAR", "max_length": 1024},
        {"name": "created_at", "dtype": "INT64"},
        {"name": "updated_at", "dtype": "INT64"},
        {"name": "deadline_at", "dtype": "INT64"},
        {"name": "embedding", "dtype": "FLOAT_VECTOR", "dim": 1024},
    ],
}


# ============================================================================
# GOALS COLLECTION
# ============================================================================

GOALS_SCHEMA = {
    "collection_name": "goals",
    "description": "Hierarchical goal definitions",
    "fields": [
        {"name": "id", "dtype": "VARCHAR", "max_length": 64, "is_primary": True},
        {"name": "task_id", "dtype": "VARCHAR", "max_length": 64},
        {"name": "description", "dtype": "VARCHAR", "max_length": 4096},
        {"name": "success_criteria_json", "dtype": "VARCHAR", "max_length": 4096},
        {"name": "input_spec_json", "dtype": "VARCHAR", "max_length": 4096},
        {"name": "output_spec_json", "dtype": "VARCHAR", "max_length": 4096},
        {"name": "constraints_json", "dtype": "VARCHAR", "max_length": 2048},
        {"name": "parent_id", "dtype": "VARCHAR", "max_length": 64},
        {"name": "children_ids_json", "dtype": "VARCHAR", "max_length": 2048},
        {"name": "status", "dtype": "VARCHAR", "max_length": 16},
        {"name": "progress", "dtype": "FLOAT"},
        {"name": "assigned_agent_id", "dtype": "VARCHAR", "max_length": 64},
        {"name": "created_at", "dtype": "INT64"},
        {"name": "completed_at", "dtype": "INT64"},
        {"name": "embedding", "dtype": "FLOAT_VECTOR", "dim": 1024},
    ],
}


# ============================================================================
# EXECUTION QUEUE COLLECTION
# ============================================================================

EXECUTION_QUEUE_SCHEMA = {
    "collection_name": "execution_queue",
    "description": "Queue of pending executions",
    "fields": [
        {"name": "id", "dtype": "VARCHAR", "max_length": 64, "is_primary": True},
        {"name": "execution_type", "dtype": "VARCHAR", "max_length": 16},
        {"name": "target_id", "dtype": "VARCHAR", "max_length": 64},
        {"name": "input_json", "dtype": "VARCHAR", "max_length": 65535},
        {"name": "priority", "dtype": "INT64"},
        {"name": "status", "dtype": "VARCHAR", "max_length": 16},
        {"name": "assigned_to", "dtype": "VARCHAR", "max_length": 64},
        {"name": "retry_count", "dtype": "INT64"},
        {"name": "max_retries", "dtype": "INT64"},
        {"name": "task_state_id", "dtype": "VARCHAR", "max_length": 64},
        {"name": "depends_on_json", "dtype": "VARCHAR", "max_length": 1024},
        {"name": "output_json", "dtype": "VARCHAR", "max_length": 65535},
        {"name": "error_json", "dtype": "VARCHAR", "max_length": 4096},
        {"name": "queued_at", "dtype": "INT64"},
        {"name": "started_at", "dtype": "INT64"},
        {"name": "completed_at", "dtype": "INT64"},
    ],
}


# ============================================================================
# DIAGNOSTICS COLLECTION
# ============================================================================

DIAGNOSTICS_SCHEMA = {
    "collection_name": "diagnostics",
    "description": "Failure and diagnostic records",
    "fields": [
        {"name": "id", "dtype": "VARCHAR", "max_length": 64, "is_primary": True},
        {"name": "failure_type", "dtype": "VARCHAR", "max_length": 32},
        {"name": "message", "dtype": "VARCHAR", "max_length": 4096},
        {"name": "context_json", "dtype": "VARCHAR", "max_length": 8192},
        {"name": "stack_trace", "dtype": "VARCHAR", "max_length": 16384},
        {"name": "timestamp", "dtype": "INT64"},
        {"name": "recoverable", "dtype": "BOOL"},
        {"name": "recovery_attempts", "dtype": "INT64"},
        {"name": "service_name", "dtype": "VARCHAR", "max_length": 64},
        {"name": "agent_id", "dtype": "VARCHAR", "max_length": 64},
    ],
}


# All schemas
ALL_SCHEMAS = [
    TOOLS_SCHEMA,
    AGENTS_SCHEMA,
    MCP_SERVERS_SCHEMA,
    TASK_STATE_SCHEMA,
    GOALS_SCHEMA,
    EXECUTION_QUEUE_SCHEMA,
    DIAGNOSTICS_SCHEMA,
]


def get_schema(collection_name: str) -> Dict:
    """Get schema by collection name"""
    for schema in ALL_SCHEMAS:
        if schema["collection_name"] == collection_name:
            return schema
    raise ValueError(f"Unknown collection: {collection_name}")
