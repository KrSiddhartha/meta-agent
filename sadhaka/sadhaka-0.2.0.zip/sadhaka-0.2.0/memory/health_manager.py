"""
Sadhaka Health Manager - Lifecycle management for tools, agents, MCP servers

Health Score Calculation:
- Base: success_rate (successful / total)
- Penalty: consecutive failures (-0.1 per failure, max -0.5)
- Penalty: high latency (if avg > threshold, -0.1)
- Boost: recent activity (+0.05 if used in last hour)
- Decay: inactivity (-0.01 per day unused, min 0.5)

Status Thresholds:
- HEALTHY: >= 0.8
- DEGRADED: 0.5 - 0.8
- UNHEALTHY: 0.2 - 0.5
- DEPRECATED: < 0.2 or manual
"""

import time
import json
import logging
from typing import Optional, Dict, List
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class EntityType(Enum):
    TOOL = "tools"
    AGENT = "agents"
    MCP_SERVER = "mcp_servers"


@dataclass
class HealthUpdate:
    """Record of an execution for health calculation"""
    success: bool
    execution_time_ms: float
    error_type: Optional[str] = None


class HealthManager:
    """
    Manages health scores for tools, agents, and MCP servers.
    
    Automatically:
    - Updates health scores after each execution
    - Tracks consecutive failures
    - Auto-deprecates consistently failing entities
    - Provides health reports
    """
    
    HEALTHY_THRESHOLD = 0.8
    DEGRADED_THRESHOLD = 0.5
    UNHEALTHY_THRESHOLD = 0.2
    
    # Auto-deprecation triggers
    MAX_CONSECUTIVE_FAILURES = 10
    MIN_SUCCESS_RATE = 0.1
    
    # Latency threshold (ms) for penalty
    HIGH_LATENCY_THRESHOLD = 5000
    
    def __init__(self, milvus_client):
        self.milvus = milvus_client
    
    def record_execution(
        self,
        entity_type: EntityType,
        entity_id: str,
        update: HealthUpdate,
    ) -> Dict:
        """
        Record an execution and update health score.
        
        Returns updated health info.
        """
        collection = entity_type.value
        
        # Get current state
        entity = self.milvus.get(collection, entity_id)
        if not entity:
            logger.warning(f"Entity {entity_id} not found in {collection}")
            return {"error": "Entity not found"}
        
        # Update counters
        total = entity.get("total_executions", 0) + 1
        successful = entity.get("successful_executions", 0) + (1 if update.success else 0)
        failed = entity.get("failed_executions", 0) + (0 if update.success else 1)
        
        # Update consecutive failures
        if update.success:
            consecutive_failures = 0
        else:
            consecutive_failures = entity.get("consecutive_failures", 0) + 1
        
        # Update average execution time (rolling average)
        old_avg = entity.get("avg_execution_time_ms", 0)
        new_avg = ((old_avg * (total - 1)) + update.execution_time_ms) / total
        
        # Update error types
        error_types = json.loads(entity.get("error_types_json", "{}"))
        if update.error_type:
            error_types[update.error_type] = error_types.get(update.error_type, 0) + 1
        
        # Calculate new health score
        health_score = self._calculate_health_score(
            total=total,
            successful=successful,
            consecutive_failures=consecutive_failures,
            avg_execution_time_ms=new_avg,
            last_execution_at=time.time(),
        )
        
        # Determine status
        health_status = self._score_to_status(health_score)
        
        # Check for auto-deprecation
        deprecation_reason = None
        if consecutive_failures >= self.MAX_CONSECUTIVE_FAILURES:
            health_status = "deprecated"
            deprecation_reason = f"Auto-deprecated: {consecutive_failures} consecutive failures"
        elif total >= 10 and (successful / total) < self.MIN_SUCCESS_RATE:
            health_status = "deprecated"
            deprecation_reason = f"Auto-deprecated: Success rate {successful/total:.1%} below minimum"
        
        # Build updates
        updates = {
            "total_executions": total,
            "successful_executions": successful,
            "failed_executions": failed,
            "consecutive_failures": consecutive_failures,
            "avg_execution_time_ms": new_avg,
            "last_execution_at": int(time.time()),
            "error_types_json": json.dumps(error_types),
            "health_score": health_score,
            "health_status": health_status,
        }
        
        if not update.success:
            updates["last_failure_at"] = int(time.time())
        
        if deprecation_reason:
            updates["deprecated_at"] = int(time.time())
            updates["deprecation_reason"] = deprecation_reason
            logger.warning(f"Entity {entity_id} deprecated: {deprecation_reason}")
        
        # Apply updates
        self.milvus.update(collection, entity_id, updates)
        
        return {
            "entity_id": entity_id,
            "health_score": health_score,
            "health_status": health_status,
            "total_executions": total,
            "success_rate": successful / total if total > 0 else 0,
            "consecutive_failures": consecutive_failures,
            "deprecated": deprecation_reason is not None,
        }
    
    def _calculate_health_score(
        self,
        total: int,
        successful: int,
        consecutive_failures: int,
        avg_execution_time_ms: float,
        last_execution_at: float,
    ) -> float:
        """Calculate health score from metrics"""
        if total == 0:
            return 1.0  # New entity starts healthy
        
        # Base: success rate
        success_rate = successful / total
        score = success_rate
        
        # Penalty: consecutive failures (-0.1 each, max -0.5)
        failure_penalty = min(consecutive_failures * 0.1, 0.5)
        score -= failure_penalty
        
        # Penalty: high latency
        if avg_execution_time_ms > self.HIGH_LATENCY_THRESHOLD:
            score -= 0.1
        
        # Decay: inactivity
        seconds_since_use = time.time() - last_execution_at
        days_since_use = seconds_since_use / 86400
        if days_since_use > 1:
            decay = min(days_since_use * 0.01, 0.3)
            score -= decay
        
        # Clamp to [0, 1]
        return max(0.0, min(1.0, score))
    
    def _score_to_status(self, score: float) -> str:
        """Convert score to status string"""
        if score >= self.HEALTHY_THRESHOLD:
            return "healthy"
        elif score >= self.DEGRADED_THRESHOLD:
            return "degraded"
        elif score >= self.UNHEALTHY_THRESHOLD:
            return "unhealthy"
        else:
            return "deprecated"
    
    def get_health(self, entity_type: EntityType, entity_id: str) -> Dict:
        """Get health info for an entity"""
        collection = entity_type.value
        entity = self.milvus.get(collection, entity_id)
        
        if not entity:
            return {"error": "Entity not found"}
        
        return {
            "entity_id": entity_id,
            "entity_type": entity_type.value,
            "health_score": entity.get("health_score", 1.0),
            "health_status": entity.get("health_status", "healthy"),
            "total_executions": entity.get("total_executions", 0),
            "successful_executions": entity.get("successful_executions", 0),
            "failed_executions": entity.get("failed_executions", 0),
            "consecutive_failures": entity.get("consecutive_failures", 0),
            "avg_execution_time_ms": entity.get("avg_execution_time_ms", 0),
            "last_execution_at": entity.get("last_execution_at"),
            "last_failure_at": entity.get("last_failure_at"),
        }
    
    def deprecate(
        self,
        entity_type: EntityType,
        entity_id: str,
        reason: str,
        replaced_by: Optional[str] = None,
    ):
        """Manually deprecate an entity"""
        collection = entity_type.value
        
        updates = {
            "health_status": "deprecated",
            "deprecated_at": int(time.time()),
            "deprecation_reason": reason,
        }
        
        if replaced_by:
            updates["replaced_by"] = replaced_by
        
        self.milvus.update(collection, entity_id, updates)
        logger.info(f"Deprecated {entity_type.value}/{entity_id}: {reason}")
    
    def restore(self, entity_type: EntityType, entity_id: str):
        """Restore a deprecated entity to healthy status"""
        collection = entity_type.value
        
        updates = {
            "health_status": "healthy",
            "health_score": 0.8,
            "consecutive_failures": 0,
            "deprecated_at": 0,
            "deprecation_reason": "",
        }
        
        self.milvus.update(collection, entity_id, updates)
        logger.info(f"Restored {entity_type.value}/{entity_id}")
    
    def run_health_check(self, entity_type: EntityType) -> Dict:
        """Run health check across all entities of a type"""
        collection = entity_type.value
        
        all_entities = self.milvus.query(
            collection_name=collection,
            filter_expr='health_status != "archived"',
        )
        
        summary = {
            "healthy": 0,
            "degraded": 0,
            "unhealthy": 0,
            "deprecated": 0,
            "total": len(all_entities),
            "stale": [],
            "at_risk": [],
        }
        
        now = time.time()
        week_ago = now - (7 * 86400)
        
        for entity in all_entities:
            status = entity.get("health_status", "unknown")
            if status in summary:
                summary[status] += 1
            
            # Check for stale entities
            last_used = entity.get("last_execution_at", 0)
            if last_used < week_ago and status != "deprecated":
                summary["stale"].append({
                    "id": entity.get("id"),
                    "name": entity.get("name"),
                    "days_unused": int((now - last_used) / 86400) if last_used > 0 else "never",
                })
            
            # Check for at-risk entities
            if entity.get("consecutive_failures", 0) >= 5:
                summary["at_risk"].append({
                    "id": entity.get("id"),
                    "name": entity.get("name"),
                    "consecutive_failures": entity.get("consecutive_failures"),
                })
        
        return summary
    
    def get_recommendations(self, entity_type: EntityType) -> List[Dict]:
        """Get health improvement recommendations"""
        health_check = self.run_health_check(entity_type)
        recommendations = []
        
        # Recommend deprecating at-risk entities
        for entity in health_check.get("at_risk", []):
            recommendations.append({
                "entity_id": entity["id"],
                "action": "investigate",
                "reason": f"High consecutive failures ({entity['consecutive_failures']})",
                "severity": "high",
            })
        
        # Recommend reviewing stale entities
        for entity in health_check.get("stale", []):
            recommendations.append({
                "entity_id": entity["id"],
                "action": "review",
                "reason": f"Unused for {entity['days_unused']} days",
                "severity": "low",
            })
        
        # Summary recommendation
        if health_check.get("unhealthy", 0) > health_check.get("healthy", 0):
            recommendations.append({
                "entity_id": None,
                "action": "system_review",
                "reason": "More unhealthy entities than healthy",
                "severity": "critical",
            })
        
        return recommendations
