"""
Sadhaka Milvus Client - Vector database wrapper

Handles connection, collection management, and CRUD operations.
Falls back to in-memory storage if Milvus is not available.
"""

import json
import time
import logging
from typing import Optional, Dict, List, Any
from dataclasses import dataclass

# Handle both package and standalone imports
try:
    from .schemas import ALL_SCHEMAS, get_schema
except ImportError:
    from schemas import ALL_SCHEMAS, get_schema

logger = logging.getLogger(__name__)


class MilvusClient:
    """
    Milvus client wrapper with fallback to in-memory storage.
    
    Provides:
    - Collection management
    - CRUD operations
    - Vector search
    - Health score queries
    """
    
    def __init__(self, uri: str = "http://localhost:19530", db_name: str = "sadhaka"):
        self.uri = uri
        self.db_name = db_name
        self._client = None
        self._use_mock = False
        self._mock_data: Dict[str, Dict[str, Dict]] = {}  # collection -> id -> data
        
        self._connect()
    
    def _connect(self):
        """Connect to Milvus or fall back to mock"""
        try:
            from pymilvus import MilvusClient as PyMilvusClient
            self._client = PyMilvusClient(uri=self.uri)
            logger.info(f"Connected to Milvus at {self.uri}")
            self._use_mock = False
        except Exception as e:
            logger.warning(f"Milvus not available ({e}), using in-memory storage")
            self._use_mock = True
            self._init_mock_collections()
    
    def _init_mock_collections(self):
        """Initialize mock collections from schemas"""
        for schema in ALL_SCHEMAS:
            self._mock_data[schema["collection_name"]] = {}
    
    # =========================================================================
    # COLLECTION MANAGEMENT
    # =========================================================================
    
    def ensure_collections(self):
        """Ensure all required collections exist"""
        for schema in ALL_SCHEMAS:
            self.ensure_collection(schema["collection_name"])
    
    def ensure_collection(self, collection_name: str):
        """Ensure a specific collection exists"""
        if self._use_mock:
            if collection_name not in self._mock_data:
                self._mock_data[collection_name] = {}
            return
        
        try:
            schema = get_schema(collection_name)
            if not self._client.has_collection(collection_name):
                # Create collection with schema
                self._client.create_collection(
                    collection_name=collection_name,
                    dimension=1024,  # Default embedding dimension
                )
                logger.info(f"Created collection: {collection_name}")
        except Exception as e:
            logger.error(f"Failed to ensure collection {collection_name}: {e}")
    
    def drop_collection(self, collection_name: str):
        """Drop a collection"""
        if self._use_mock:
            self._mock_data.pop(collection_name, None)
            return
        
        try:
            self._client.drop_collection(collection_name)
            logger.info(f"Dropped collection: {collection_name}")
        except Exception as e:
            logger.error(f"Failed to drop collection {collection_name}: {e}")
    
    # =========================================================================
    # CRUD OPERATIONS
    # =========================================================================
    
    def insert(self, collection_name: str, data: Dict[str, Any]) -> str:
        """Insert a single record"""
        if self._use_mock:
            if collection_name not in self._mock_data:
                self._mock_data[collection_name] = {}
            
            record_id = data.get("id", str(time.time()))
            self._mock_data[collection_name][record_id] = data.copy()
            return record_id
        
        try:
            self.ensure_collection(collection_name)
            self._client.insert(collection_name=collection_name, data=[data])
            return data.get("id", "")
        except Exception as e:
            logger.error(f"Insert failed: {e}")
            # Fall back to mock
            return self._mock_insert(collection_name, data)
    
    def _mock_insert(self, collection_name: str, data: Dict) -> str:
        """Mock insert for fallback"""
        if collection_name not in self._mock_data:
            self._mock_data[collection_name] = {}
        record_id = data.get("id", str(time.time()))
        self._mock_data[collection_name][record_id] = data.copy()
        return record_id
    
    def get(self, collection_name: str, record_id: str) -> Optional[Dict]:
        """Get a single record by ID"""
        if self._use_mock:
            collection = self._mock_data.get(collection_name, {})
            return collection.get(record_id)
        
        try:
            results = self._client.get(
                collection_name=collection_name,
                ids=[record_id],
            )
            return results[0] if results else None
        except Exception as e:
            logger.error(f"Get failed: {e}")
            return self._mock_data.get(collection_name, {}).get(record_id)
    
    def update(self, collection_name: str, record_id: str, updates: Dict[str, Any]):
        """Update a record"""
        if self._use_mock:
            if collection_name in self._mock_data and record_id in self._mock_data[collection_name]:
                self._mock_data[collection_name][record_id].update(updates)
            return
        
        try:
            # Milvus doesn't have native update, so we upsert
            existing = self.get(collection_name, record_id)
            if existing:
                existing.update(updates)
                self._client.upsert(collection_name=collection_name, data=[existing])
        except Exception as e:
            logger.error(f"Update failed: {e}")
            # Fall back to mock update
            if collection_name in self._mock_data and record_id in self._mock_data[collection_name]:
                self._mock_data[collection_name][record_id].update(updates)
    
    def upsert(self, collection_name: str, data: Dict[str, Any]):
        """Insert or update a record"""
        if self._use_mock:
            record_id = data.get("id")
            if record_id:
                if collection_name not in self._mock_data:
                    self._mock_data[collection_name] = {}
                self._mock_data[collection_name][record_id] = data.copy()
            return
        
        try:
            self.ensure_collection(collection_name)
            self._client.upsert(collection_name=collection_name, data=[data])
        except Exception as e:
            logger.error(f"Upsert failed: {e}")
            self._mock_insert(collection_name, data)
    
    def delete(self, collection_name: str, record_id: str):
        """Delete a record"""
        if self._use_mock:
            if collection_name in self._mock_data:
                self._mock_data[collection_name].pop(record_id, None)
            return
        
        try:
            self._client.delete(collection_name=collection_name, ids=[record_id])
        except Exception as e:
            logger.error(f"Delete failed: {e}")
    
    # =========================================================================
    # QUERY OPERATIONS
    # =========================================================================
    
    def query(
        self,
        collection_name: str,
        filter_expr: str = "",
        output_fields: List[str] = None,
        limit: int = 100,
    ) -> List[Dict]:
        """Query records with filter expression"""
        if self._use_mock:
            return self._mock_query(collection_name, filter_expr, limit)
        
        try:
            results = self._client.query(
                collection_name=collection_name,
                filter=filter_expr,
                output_fields=output_fields or ["*"],
                limit=limit,
            )
            return results
        except Exception as e:
            logger.error(f"Query failed: {e}")
            return self._mock_query(collection_name, filter_expr, limit)
    
    def _mock_query(self, collection_name: str, filter_expr: str, limit: int) -> List[Dict]:
        """Mock query implementation"""
        collection = self._mock_data.get(collection_name, {})
        results = list(collection.values())
        
        # Simple filter parsing for common cases
        if filter_expr:
            if ">=" in filter_expr:
                parts = filter_expr.split(">=")
                if len(parts) == 2:
                    field = parts[0].strip()
                    value = float(parts[1].strip())
                    results = [r for r in results if r.get(field, 0) >= value]
            elif "==" in filter_expr:
                parts = filter_expr.split("==")
                if len(parts) == 2:
                    field = parts[0].strip()
                    value = parts[1].strip().strip('"\'')
                    results = [r for r in results if str(r.get(field, "")) == value]
            elif "!=" in filter_expr:
                parts = filter_expr.split("!=")
                if len(parts) == 2:
                    field = parts[0].strip()
                    value = parts[1].strip().strip('"\'')
                    results = [r for r in results if str(r.get(field, "")) != value]
        
        return results[:limit]
    
    def search(
        self,
        collection_name: str,
        query_vector: List[float],
        limit: int = 10,
        filter_expr: str = "",
        output_fields: List[str] = None,
    ) -> List[Dict]:
        """Vector similarity search"""
        if self._use_mock:
            # Return all matching filter, limited
            results = self._mock_query(collection_name, filter_expr, limit)
            # Add mock distances
            for i, r in enumerate(results):
                r["_distance"] = i * 0.1
            return results
        
        try:
            results = self._client.search(
                collection_name=collection_name,
                data=[query_vector],
                limit=limit,
                filter=filter_expr,
                output_fields=output_fields or ["*"],
            )
            return results[0] if results else []
        except Exception as e:
            logger.error(f"Search failed: {e}")
            return self._mock_query(collection_name, filter_expr, limit)
    
    # =========================================================================
    # HEALTH-SPECIFIC QUERIES
    # =========================================================================
    
    def get_healthy_entities(
        self,
        collection_name: str,
        min_score: float = 0.5,
    ) -> List[Dict]:
        """Get entities with health score above threshold"""
        filter_expr = f'health_score >= {min_score}'
        return self.query(collection_name, filter_expr)
    
    def get_deprecated_entities(self, collection_name: str) -> List[Dict]:
        """Get deprecated entities"""
        return self.query(collection_name, 'health_status == "deprecated"')
    
    def get_unhealthy_entities(self, collection_name: str) -> List[Dict]:
        """Get unhealthy entities that may need attention"""
        return self.query(collection_name, 'health_score < 0.5')
    
    # =========================================================================
    # UTILITY
    # =========================================================================
    
    def count(self, collection_name: str) -> int:
        """Count records in collection"""
        if self._use_mock:
            return len(self._mock_data.get(collection_name, {}))
        
        try:
            return self._client.num_entities(collection_name)
        except Exception:
            return len(self._mock_data.get(collection_name, {}))
    
    def list_collections(self) -> List[str]:
        """List all collections"""
        if self._use_mock:
            return list(self._mock_data.keys())
        
        try:
            return self._client.list_collections()
        except Exception:
            return list(self._mock_data.keys())
    
    def is_connected(self) -> bool:
        """Check if connected to Milvus"""
        return not self._use_mock
    
    def get_stats(self) -> Dict:
        """Get database statistics"""
        collections = self.list_collections()
        return {
            "connected": not self._use_mock,
            "uri": self.uri,
            "collections": len(collections),
            "collection_counts": {
                c: self.count(c) for c in collections
            }
        }
