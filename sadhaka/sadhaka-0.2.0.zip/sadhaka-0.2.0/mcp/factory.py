"""
Sadhaka MCP Factory - Agent-created MCP servers
"""

import uuid
import json
import time
import logging
from pathlib import Path
from typing import Optional, Dict, List
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class MCPServerConfig:
    """Configuration for an MCP server"""
    id: str
    name: str
    description: str
    transport: str = "stdio"
    tools: List[Dict] = field(default_factory=list)
    source_code: str = ""
    port: Optional[int] = None
    status: str = "stopped"


class MCPServerFactory:
    """Creates MCP servers from agent specifications."""
    
    def __init__(self, servers_dir: str = "/tmp/sadhaka/mcp_servers", milvus_client=None):
        self.servers_dir = Path(servers_dir)
        self.servers_dir.mkdir(parents=True, exist_ok=True)
        self.milvus = milvus_client
        self.servers: Dict[str, MCPServerConfig] = {}
    
    def create_server(
        self,
        name: str,
        description: str,
        tools: List[Dict],
        transport: str = "stdio",
    ) -> MCPServerConfig:
        """Create a new MCP server from tool specifications."""
        server_id = f"{name}_{uuid.uuid4().hex[:8]}"
        
        # Generate tool implementations
        tool_impls = []
        tool_regs = []
        
        for tool in tools:
            tool_name = tool["name"]
            tool_desc = tool.get("description", "")
            tool_code = tool.get("implementation", "return 'Not implemented'")
            
            # Create function
            params = tool.get("parameters", {}).get("properties", {})
            param_str = ", ".join(params.keys()) if params else ""
            
            tool_impls.append(f'''
def tool_{tool_name}({param_str}):
    """{tool_desc}"""
    {tool_code}
''')
            tool_regs.append(f'server.register_tool("{tool_name}", tool_{tool_name}, "{tool_desc}")')
        
        # Generate source code
        source_code = f'''"""MCP Server: {name} - {description}"""
import asyncio
import json
import sys

class MCPServer:
    def __init__(self, name):
        self.name = name
        self.tools = {{}}
    
    def register_tool(self, name, func, description=""):
        self.tools[name] = {{"func": func, "description": description}}
    
    async def handle_request(self, request):
        method = request.get("method")
        params = request.get("params", {{}})
        
        if method == "tools/list":
            return {{"tools": [
                {{"name": n, "description": i["description"]}}
                for n, i in self.tools.items()
            ]}}
        elif method == "tools/call":
            tool_name = params.get("name")
            args = params.get("arguments", {{}})
            if tool_name in self.tools:
                result = self.tools[tool_name]["func"](**args)
                return {{"content": [{{"type": "text", "text": str(result)}}]}}
            return {{"error": f"Unknown tool: {{tool_name}}"}}
        return {{"error": f"Unknown method: {{method}}"}}
    
    async def run_stdio(self):
        while True:
            try:
                line = sys.stdin.readline()
                if not line:
                    break
                request = json.loads(line)
                response = await self.handle_request(request)
                print(json.dumps(response), flush=True)
            except Exception as e:
                print(json.dumps({{"error": str(e)}}), flush=True)

server = MCPServer("{name}")

{"".join(tool_impls)}

{chr(10).join(tool_regs)}

if __name__ == "__main__":
    asyncio.run(server.run_stdio())
'''
        
        config = MCPServerConfig(
            id=server_id,
            name=name,
            description=description,
            transport=transport,
            tools=tools,
            source_code=source_code,
        )
        
        # Save to disk
        self._save_server_file(config)
        
        # Save to Milvus
        if self.milvus:
            self._save_to_milvus(config)
        
        self.servers[server_id] = config
        logger.info(f"Created MCP server: {server_id}")
        
        return config
    
    def _save_server_file(self, config: MCPServerConfig):
        """Save server code to file"""
        server_file = self.servers_dir / f"{config.id}.py"
        server_file.write_text(config.source_code)
    
    def _save_to_milvus(self, config: MCPServerConfig):
        """Save server config to Milvus"""
        self.milvus.upsert("mcp_servers", {
            "id": config.id,
            "name": config.name,
            "version": 1,
            "description": config.description,
            "transport_type": config.transport,
            "container_id": "",
            "port": config.port or 0,
            "source_code": config.source_code