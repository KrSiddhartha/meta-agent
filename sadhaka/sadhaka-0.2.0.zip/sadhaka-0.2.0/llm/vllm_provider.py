"""
Sadhaka vLLM Provider - Full KV-Cache Sharing for Latent Collaboration

This module provides the core LLM functionality with:
- Prefix caching for shared context across agents
- Multi-agent parallel generation
- Sequential latent transfer between agents
- Token savings tracking
"""

import hashlib
import time
import logging
from typing import Optional, Dict, List, Any
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class SharedContext:
    """Shared prefix context - KV computed once, reused by all agents"""
    id: str
    content: str
    token_ids: List[int]
    token_count: int
    created_at: float
    access_count: int = 0


@dataclass
class LatentState:
    """Captured KV-cache state metadata for transfer between agents"""
    agent_id: str
    context_id: str
    prompt_tokens: int
    generation_tokens: int
    content_hash: str
    timestamp: float


@dataclass
class GenerationResult:
    """Result from generation with latent tracking"""
    text: str
    agent_id: str
    prompt_tokens: int
    generation_tokens: int
    latent_state: Optional[LatentState]
    kv_cache_hit: bool
    time_ms: float


class VLLMLatentProvider:
    """
    vLLM provider with full KV-cache sharing for latent collaboration.
    
    How it works:
    1. Create shared context (system prompt + task + tools)
    2. vLLM computes KV-cache for shared context ONCE
    3. Multiple agents generate with same prefix
    4. vLLM reuses KV blocks automatically (prefix caching)
    5. Each agent only computes KV for their unique suffix
    
    Token savings: 60-80% for multi-agent scenarios
    """
    
    def __init__(
        self,
        model: str = "Qwen/Qwen2.5-7B-Instruct",
        tensor_parallel_size: int = 1,
        gpu_memory_utilization: float = 0.9,
        max_model_len: int = 32768,
        max_num_seqs: int = 256,
    ):
        self.model_name = model
        self.tensor_parallel_size = tensor_parallel_size
        self.gpu_memory_utilization = gpu_memory_utilization
        self.max_model_len = max_model_len
        self.max_num_seqs = max_num_seqs
        
        # Lazy load vLLM
        self._llm = None
        self._tokenizer = None
        
        # Track shared contexts
        self.shared_contexts: Dict[str, SharedContext] = {}
        
        # Track latent states per agent
        self.agent_latent_states: Dict[str, LatentState] = {}
        
        # Default sampling params (stored as dict for lazy vLLM import)
        self._default_sampling_params = {
            "temperature": 0.7,
            "top_p": 0.9,
            "max_tokens": 2048,
        }
        
        logger.info(f"VLLMLatentProvider configured: {model}")
    
    @property
    def llm(self):
        """Lazy load vLLM"""
        if self._llm is None:
            try:
                from vllm import LLM
                self._llm = LLM(
                    model=self.model_name,
                    tensor_parallel_size=self.tensor_parallel_size,
                    gpu_memory_utilization=self.gpu_memory_utilization,
                    max_model_len=self.max_model_len,
                    max_num_seqs=self.max_num_seqs,
                    trust_remote_code=True,
                    enable_prefix_caching=True,
                    enable_chunked_prefill=True,
                )
                logger.info("vLLM loaded with prefix caching enabled")
            except ImportError:
                logger.warning("vLLM not available, using mock mode")
                self._llm = MockLLM(self.model_name)
        return self._llm
    
    @property
    def tokenizer(self):
        """Get tokenizer"""
        if self._tokenizer is None:
            if hasattr(self.llm, 'get_tokenizer'):
                self._tokenizer = self.llm.get_tokenizer()
            else:
                self._tokenizer = MockTokenizer()
        return self._tokenizer
    
    def _get_sampling_params(self, **kwargs):
        """Get sampling params, merging with defaults"""
        try:
            from vllm import SamplingParams
            params = {**self._default_sampling_params, **kwargs}
            return SamplingParams(**params)
        except ImportError:
            return {**self._default_sampling_params, **kwargs}
    
    # =========================================================================
    # SHARED CONTEXT MANAGEMENT
    # =========================================================================
    
    def create_shared_context(
        self,
        context_id: str,
        content: str,
        warm_cache: bool = True,
    ) -> SharedContext:
        """
        Create a shared context for multiple agents.
        
        This prefix will be computed once and reused for all agents
        that generate with this context.
        """
        token_ids = self.tokenizer.encode(content)
        if isinstance(token_ids, list):
            token_count = len(token_ids)
        else:
            token_count = len(token_ids) if hasattr(token_ids, '__len__') else 0
        
        context = SharedContext(
            id=context_id,
            content=content,
            token_ids=token_ids if isinstance(token_ids, list) else list(token_ids),
            token_count=token_count,
            created_at=time.time(),
        )
        
        self.shared_contexts[context_id] = context
        
        if warm_cache:
            self._warm_cache(content)
        
        logger.info(f"Created shared context '{context_id}': {token_count} tokens")
        return context
    
    def update_shared_context(self, context_id: str, content: str) -> SharedContext:
        """Update shared context with new content"""
        return self.create_shared_context(context_id, content, warm_cache=True)
    
    def _warm_cache(self, prefix: str):
        """Pre-compute KV cache for a prefix"""
        try:
            params = self._get_sampling_params(max_tokens=1)
            self.llm.generate([prefix + "\n"], params)
            logger.debug("KV cache warmed")
        except Exception as e:
            logger.warning(f"Cache warming failed: {e}")
    
    # =========================================================================
    # SINGLE AGENT GENERATION
    # =========================================================================
    
    def generate(
        self,
        prompt: str,
        agent_id: str,
        context_id: Optional[str] = None,
        **sampling_kwargs,
    ) -> GenerationResult:
        """
        Generate response for a single agent.
        
        If context_id is provided, uses shared KV cache for that context.
        """
        params = self._get_sampling_params(**sampling_kwargs)
        start_time = time.time()
        
        # Build full prompt
        if context_id and context_id in self.shared_contexts:
            shared = self.shared_contexts[context_id]
            shared.access_count += 1
            full_prompt = shared.content + prompt
            prefix_tokens = shared.token_count
            kv_cache_hit = True
        else:
            full_prompt = prompt
            prefix_tokens = 0
            kv_cache_hit = False
        
        # Generate
        outputs = self.llm.generate([full_prompt], params)
        output = outputs[0]
        
        # Extract results
        if hasattr(output, 'outputs'):
            generated_text = output.outputs[0].text
            prompt_tokens = len(output.prompt_token_ids) if hasattr(output, 'prompt_token_ids') else prefix_tokens
            generation_tokens = len(output.outputs[0].token_ids) if hasattr(output.outputs[0], 'token_ids') else len(generated_text.split())
        else:
            # Mock mode
            generated_text = output.get('text', str(output))
            prompt_tokens = prefix_tokens + len(prompt.split())
            generation_tokens = len(generated_text.split())
        
        # Track latent state
        latent_state = LatentState(
            agent_id=agent_id,
            context_id=context_id or "none",
            prompt_tokens=prompt_tokens,
            generation_tokens=generation_tokens,
            content_hash=hashlib.md5(full_prompt.encode()).hexdigest()[:16],
            timestamp=time.time(),
        )
        self.agent_latent_states[agent_id] = latent_state
        
        elapsed_ms = (time.time() - start_time) * 1000
        
        return GenerationResult(
            text=generated_text,
            agent_id=agent_id,
            prompt_tokens=prompt_tokens,
            generation_tokens=generation_tokens,
            latent_state=latent_state,
            kv_cache_hit=kv_cache_hit,
            time_ms=elapsed_ms,
        )
    
    # =========================================================================
    # MULTI-AGENT PARALLEL GENERATION (KV sharing)
    # =========================================================================
    
    def generate_multi_agent(
        self,
        context_id: str,
        agent_prompts: List[Dict[str, str]],
        **sampling_kwargs,
    ) -> List[GenerationResult]:
        """
        Generate responses for multiple agents sharing the same context.
        
        All agents share the same prefix (system + task + blackboard state).
        vLLM computes KV for prefix ONCE.
        Each agent's unique query is computed separately.
        Massive token savings.
        """
        if context_id not in self.shared_contexts:
            raise ValueError(f"Unknown context: {context_id}")
        
        shared = self.shared_contexts[context_id]
        shared.access_count += len(agent_prompts)
        params = self._get_sampling_params(**sampling_kwargs)
        
        start_time = time.time()
        
        # Build all prompts with shared prefix
        full_prompts = []
        agent_ids = []
        
        for ap in agent_prompts:
            full_prompts.append(shared.content + ap["prompt"])
            agent_ids.append(ap["agent_id"])
        
        # vLLM batches these and automatically reuses KV for shared prefix
        outputs = self.llm.generate(full_prompts, params)
        
        elapsed_ms = (time.time() - start_time) * 1000
        per_agent_ms = elapsed_ms / len(agent_prompts)
        
        results = []
        for agent_id, output in zip(agent_ids, outputs):
            if hasattr(output, 'outputs'):
                generated_text = output.outputs[0].text
                prompt_tokens = len(output.prompt_token_ids) if hasattr(output, 'prompt_token_ids') else shared.token_count
                generation_tokens = len(output.outputs[0].token_ids) if hasattr(output.outputs[0], 'token_ids') else len(generated_text.split())
            else:
                generated_text = output.get('text', str(output))
                prompt_tokens = shared.token_count
                generation_tokens = len(generated_text.split())
            
            latent_state = LatentState(
                agent_id=agent_id,
                context_id=context_id,
                prompt_tokens=prompt_tokens,
                generation_tokens=generation_tokens,
                content_hash=hashlib.md5(f"{shared.content}{agent_id}".encode()).hexdigest()[:16],
                timestamp=time.time(),
            )
            self.agent_latent_states[agent_id] = latent_state
            
            results.append(GenerationResult(
                text=generated_text,
                agent_id=agent_id,
                prompt_tokens=prompt_tokens,
                generation_tokens=generation_tokens,
                latent_state=latent_state,
                kv_cache_hit=True,
                time_ms=per_agent_ms,
            ))
        
        logger.info(
            f"Multi-agent generation: {len(agent_prompts)} agents, "
            f"{shared.token_count} shared tokens, {elapsed_ms:.0f}ms total"
        )
        
        return results
    
    # =========================================================================
    # SEQUENTIAL LATENT TRANSFER (Agent A → Agent B)
    # =========================================================================
    
    def generate_with_predecessor(
        self,
        prompt: str,
        agent_id: str,
        predecessor_agent_id: str,
        predecessor_output: str,
        context_id: Optional[str] = None,
        **sampling_kwargs,
    ) -> GenerationResult:
        """
        Generate with latent transfer from predecessor agent.
        
        The predecessor's output becomes part of the prompt,
        and if using shared context, KV for context is reused.
        """
        combined_prompt = f"""Previous agent ({predecessor_agent_id}) output:
{predecessor_output}

Your task:
{prompt}"""
        
        return self.generate(
            prompt=combined_prompt,
            agent_id=agent_id,
            context_id=context_id,
            **sampling_kwargs,
        )
    
    # =========================================================================
    # STATISTICS & MONITORING
    # =========================================================================
    
    def get_cache_stats(self) -> Dict:
        """Get KV cache utilization statistics"""
        total_shared_tokens = sum(c.token_count for c in self.shared_contexts.values())
        total_accesses = sum(c.access_count for c in self.shared_contexts.values())
        
        # Estimate savings
        if total_accesses > 0 and self.shared_contexts:
            avg_shared = total_shared_tokens / len(self.shared_contexts)
            tokens_without_sharing = total_accesses * avg_shared
            tokens_with_sharing = total_shared_tokens + (total_accesses * 100)
            savings_pct = (1 - tokens_with_sharing / max(tokens_without_sharing, 1)) * 100
        else:
            savings_pct = 0
        
        return {
            "shared_contexts": len(self.shared_contexts),
            "total_shared_tokens": total_shared_tokens,
            "total_context_accesses": total_accesses,
            "estimated_token_savings_pct": round(max(0, savings_pct), 1),
            "active_agent_states": len(self.agent_latent_states),
            "contexts": [
                {
                    "id": c.id,
                    "tokens": c.token_count,
                    "accesses": c.access_count,
                    "age_seconds": round(time.time() - c.created_at, 1),
                }
                for c in self.shared_contexts.values()
            ]
        }
    
    def get_agent_latent_state(self, agent_id: str) -> Optional[LatentState]:
        """Get latent state for an agent"""
        return self.agent_latent_states.get(agent_id)
    
    # =========================================================================
    # CONTEXT BUILDERS
    # =========================================================================
    
    def build_shared_context_content(
        self,
        system_prompt: str,
        task_description: str,
        goal: Dict,
        blackboard_state: Dict,
        available_tools: List[Dict],
    ) -> str:
        """Build the shared context content from components"""
        tools_str = "\n".join([
            f"- {t['name']}: {t.get('description', 'No description')}"
            for t in available_tools
        ]) if available_tools else "No tools available"
        
        goal_desc = goal.get('description', 'No goal defined') if goal else 'No goal defined'
        criteria = goal.get('success_criteria', []) if goal else []
        goal_str = f"Goal: {goal_desc}\nSuccess Criteria:\n" + "\n".join(f'- {c}' for c in criteria)
        
        blackboard_str = "\n".join([
            f"- {k}: {v}"
            for k, v in (blackboard_state or {}).items()
        ]) if blackboard_state else "Empty"
        
        return f"""{system_prompt}

=== TASK ===
{task_description}

=== GOAL ===
{goal_str}

=== CURRENT STATE (Blackboard) ===
{blackboard_str}

=== AVAILABLE TOOLS ===
{tools_str}

=== INSTRUCTIONS ===
You are one of several agents working on this task.
Read the blackboard state to understand current progress.
Write your outputs to the blackboard for other agents.
Use tools when needed. Follow the goal precisely.

"""


# =========================================================================
# MOCK CLASSES FOR TESTING WITHOUT vLLM
# =========================================================================

class MockTokenizer:
    """Mock tokenizer for testing without vLLM"""
    
    def encode(self, text: str) -> List[int]:
        # Rough approximation: 4 chars per token
        return list(range(len(text) // 4 + 1))
    
    def decode(self, token_ids: List[int]) -> str:
        return f"[decoded {len(token_ids)} tokens]"


class MockLLM:
    """Mock LLM for testing without vLLM"""
    
    def __init__(self, model_name: str):
        self.model_name = model_name
        self._tokenizer = MockTokenizer()
    
    def get_tokenizer(self):
        return self._tokenizer
    
    def generate(self, prompts: List[str], params) -> List[Dict]:
        results = []
        for prompt in prompts:
            # Generate a mock response based on prompt content
            if "Thought:" in prompt or "think" in prompt.lower():
                text = "Thought: I need to analyze this task carefully.\nAction: analyze\nAction Input: {}"
            elif "code" in prompt.lower():
                text = "```python\ndef solution():\n    return 'Hello, World!'\n```"
            else:
                text = f"Mock response for prompt of length {len(prompt)}"
            
            results.append({
                "text": text,
                "prompt_tokens": len(prompt) // 4,
                "generation_tokens": len(text) // 4,
            })
        return results
