# Sadhaka (साधक) - The one who accomplishes
"""
Production-grade AI agent framework implementing the 4 pillars:
1. Durable Memory (Milvus + Blackboard)
2. Explicit Tools (Schema-validated)
3. Specific Goal Definition (Goal Tree)
4. Recovery Logic (Retries + Circuit Breakers)

Plus: Latent Collaboration via vLLM KV-cache sharing
"""

__version__ = "0.2.0"
__author__ = "Sadhaka Contributors"
__license__ = "MIT"

from .config import SadhakaConfig, DEFAULT_CONFIG

__all__ = [
    "__version__",
    "SadhakaConfig",
    "DEFAULT_CONFIG",
]

# Lazy imports to avoid circular dependencies
def get_agent():
    from .core.agent import SadhakaAgent
    return SadhakaAgent

def get_tools():
    from .core.tools import ToolRegistry, Tool
    return ToolRegistry, Tool

def get_tracer():
    from .core.tracing import Tracer, ExecutionTrace
    return Tracer, ExecutionTrace

def get_safety():
    from .core.safety import SafetyGuard
    return SafetyGuard
