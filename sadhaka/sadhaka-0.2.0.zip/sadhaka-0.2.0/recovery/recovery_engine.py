"""
Sadhaka Recovery Engine - Resilience for agent operations

Pillar 4: Recovery Logic
"Resilience transforms agents — retries and diagnostics prevent collapse"

Features:
- Retries with exponential backoff
- Circuit breakers per service
- Checkpointing for long tasks
- Diagnostics collection
- Fallback strategies
"""

import asyncio
import time
import traceback
import logging
from typing import Callable, Optional, Dict, List, Any
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)


class FailureType(Enum):
    TIMEOUT = "timeout"
    TOOL_ERROR = "tool_error"
    LLM_ERROR = "llm_error"
    VALIDATION_ERROR = "validation_error"
    RESOURCE_ERROR = "resource_error"
    DOCKER_ERROR = "docker_error"
    MCP_ERROR = "mcp_error"
    UNKNOWN = "unknown"


@dataclass
class Failure:
    """Structured failure record"""
    id: str
    failure_type: FailureType
    message: str
    context: Dict[str, Any]
    timestamp: float
    stack_trace: Optional[str] = None
    recoverable: bool = True
    recovery_attempts: int = 0


@dataclass
class RecoveryStrategy:
    """Strategy for recovering from a failure type"""
    failure_type: FailureType
    max_retries: int
    backoff_base: float
    backoff_max: float
    recovery_action: Optional[Callable] = None
    fallback_action: Optional[Callable] = None


class CircuitBreaker:
    """
    Prevents cascade failures.
    
    States:
    - CLOSED: Normal operation
    - OPEN: Too many failures, reject all calls
    - HALF_OPEN: Testing if service recovered
    """
    
    def __init__(
        self,
        name: str,
        failure_threshold: int = 5,
        recovery_timeout: float = 30.0,
    ):
        self.name = name
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        
        self.failures = 0
        self.last_failure_time = 0
        self.state = "CLOSED"
    
    def record_success(self):
        """Record successful call"""
        self.failures = 0
        self.state = "CLOSED"
    
    def record_failure(self):
        """Record failed call"""
        self.failures += 1
        self.last_failure_time = time.time()
        
        if self.failures >= self.failure_threshold:
            self.state = "OPEN"
            logger.warning(f"Circuit {self.name} OPEN after {self.failures} failures")
    
    def can_execute(self) -> bool:
        """Check if calls are allowed"""
        if self.state == "CLOSED":
            return True
        
        if self.state == "OPEN":
            if time.time() - self.last_failure_time > self.recovery_timeout:
                self.state = "HALF_OPEN"
                return True
            return False
        
        # HALF_OPEN: Allow one test call
        return True
    
    def get_state(self) -> Dict:
        """Get circuit breaker state"""
        return {
            "name": self.name,
            "state": self.state,
            "failures": self.failures,
            "last_failure": self.last_failure_time,
        }


class RecoveryEngine:
    """
    Central recovery logic for Sadhaka.
    
    Handles:
    - Retries with exponential backoff
    - Circuit breakers per service
    - Checkpointing for long tasks
    - Diagnostics collection
    - Fallback strategies
    """
    
    def __init__(self, milvus_client=None):
        self.milvus = milvus_client
        self.failures: List[Failure] = []
        self.circuit_breakers: Dict[str, CircuitBreaker] = {}
        self.checkpoints: Dict[str, Dict] = {}
        
        # Default strategies per failure type
        self.strategies: Dict[FailureType, RecoveryStrategy] = {
            FailureType.TIMEOUT: RecoveryStrategy(
                failure_type=FailureType.TIMEOUT,
                max_retries=3,
                backoff_base=2.0,
                backoff_max=30.0,
            ),
            FailureType.TOOL_ERROR: RecoveryStrategy(
                failure_type=FailureType.TOOL_ERROR,
                max_retries=2,
                backoff_base=1.0,
                backoff_max=10.0,
            ),
            FailureType.LLM_ERROR: RecoveryStrategy(
                failure_type=FailureType.LLM_ERROR,
                max_retries=3,
                backoff_base=5.0,
                backoff_max=60.0,
            ),
            FailureType.DOCKER_ERROR: RecoveryStrategy(
                failure_type=FailureType.DOCKER_ERROR,
                max_retries=2,
                backoff_base=3.0,
                backoff_max=20.0,
            ),
            FailureType.MCP_ERROR: RecoveryStrategy(
                failure_type=FailureType.MCP_ERROR,
                max_retries=2,
                backoff_base=2.0,
                backoff_max=15.0,
            ),
            FailureType.UNKNOWN: RecoveryStrategy(
                failure_type=FailureType.UNKNOWN,
                max_retries=1,
                backoff_base=1.0,
                backoff_max=10.0,
            ),
        }
    
    def get_circuit_breaker(self, service_name: str) -> CircuitBreaker:
        """Get or create circuit breaker for a service"""
        if service_name not in self.circuit_breakers:
            self.circuit_breakers[service_name] = CircuitBreaker(service_name)
        return self.circuit_breakers[service_name]
    
    async def execute_with_recovery(
        self,
        func: Callable,
        *args,
        service_name: str = "default",
        failure_type: FailureType = FailureType.UNKNOWN,
        context: Dict = None,
        **kwargs,
    ) -> Any:
        """
        Execute function with full recovery logic.
        
        - Checks circuit breaker
        - Retries with backoff
        - Records failures for diagnostics
        - Calls fallback if all retries fail
        """
        circuit = self.get_circuit_breaker(service_name)
        strategy = self.strategies.get(failure_type, self.strategies[FailureType.UNKNOWN])
        
        # Check circuit breaker
        if not circuit.can_execute():
            raise RuntimeError(f"Circuit breaker {service_name} is OPEN")
        
        last_error = None
        
        for attempt in range(strategy.max_retries + 1):
            try:
                # Execute the function
                if asyncio.iscoroutinefunction(func):
                    result = await func(*args, **kwargs)
                else:
                    result = func(*args, **kwargs)
                
                # Success
                circuit.record_success()
                return result
                
            except Exception as e:
                last_error = e
                
                # Record failure
                failure = Failure(
                    id=f"fail_{int(time.time())}_{attempt}",
                    failure_type=failure_type,
                    message=str(e),
                    context=context or {},
                    timestamp=time.time(),
                    stack_trace=traceback.format_exc(),
                    recovery_attempts=attempt + 1,
                )
                self.failures.append(failure)
                self._save_failure(failure)
                
                circuit.record_failure()
                
                # Check if should retry
                if attempt < strategy.max_retries:
                    backoff = min(
                        strategy.backoff_base * (2 ** attempt),
                        strategy.backoff_max
                    )
                    
                    logger.warning(
                        f"Attempt {attempt + 1}/{strategy.max_retries + 1} failed for {service_name}. "
                        f"Retrying in {backoff:.1f}s. Error: {e}"
                    )
                    
                    # Custom recovery action before retry
                    if strategy.recovery_action:
                        try:
                            if asyncio.iscoroutinefunction(strategy.recovery_action):
                                await strategy.recovery_action(failure)
                            else:
                                strategy.recovery_action(failure)
                        except Exception as re:
                            logger.error(f"Recovery action failed: {re}")
                    
                    await asyncio.sleep(backoff)
                else:
                    logger.error(f"All retries exhausted for {service_name}: {e}")
        
        # All retries failed - try fallback
        if strategy.fallback_action:
            logger.info(f"Executing fallback for {service_name}")
            try:
                if asyncio.iscoroutinefunction(strategy.fallback_action):
                    return await strategy.fallback_action(*args, **kwargs)
                else:
                    return strategy.fallback_action(*args, **kwargs)
            except Exception as fe:
                logger.error(f"Fallback also failed: {fe}")
        
        raise last_error
    
    def execute_with_recovery_sync(
        self,
        func: Callable,
        *args,
        service_name: str = "default",
        failure_type: FailureType = FailureType.UNKNOWN,
        context: Dict = None,
        **kwargs,
    ) -> Any:
        """Synchronous version of execute_with_recovery"""
        circuit = self.get_circuit_breaker(service_name)
        strategy = self.strategies.get(failure_type, self.strategies[FailureType.UNKNOWN])
        
        if not circuit.can_execute():
            raise RuntimeError(f"Circuit breaker {service_name} is OPEN")
        
        last_error = None
        
        for attempt in range(strategy.max_retries + 1):
            try:
                result = func(*args, **kwargs)
                circuit.record_success()
                return result
                
            except Exception as e:
                last_error = e
                
                failure = Failure(
                    id=f"fail_{int(time.time())}_{attempt}",
                    failure_type=failure_type,
                    message=str(e),
                    context=context or {},
                    timestamp=time.time(),
                    stack_trace=traceback.format_exc(),
                    recovery_attempts=attempt + 1,
                )
                self.failures.append(failure)
                circuit.record_failure()
                
                if attempt < strategy.max_retries:
                    backoff = min(
                        strategy.backoff_base * (2 ** attempt),
                        strategy.backoff_max
                    )
                    logger.warning(f"Retry {attempt + 1} in {backoff:.1f}s for {service_name}")
                    time.sleep(backoff)
        
        raise last_error
    
    # =========================================================================
    # CHECKPOINTING
    # =========================================================================
    
    def save_checkpoint(self, task_id: str, state: Dict) -> str:
        """Save checkpoint for task resumption"""
        checkpoint_id = f"cp_{task_id}_{int(time.time())}"
        
        checkpoint = {
            "id": checkpoint_id,
            "task_id": task_id,
            "state": state,
            "timestamp": time.time(),
        }
        
        self.checkpoints[task_id] = checkpoint
        
        logger.info(f"Saved checkpoint {checkpoint_id} for task {task_id}")
        return checkpoint_id
    
    def get_checkpoint(self, task_id: str) -> Optional[Dict]:
        """Get latest checkpoint for a task"""
        return self.checkpoints.get(task_id)
    
    def clear_checkpoint(self, task_id: str):
        """Clear checkpoint after task completion"""
        self.checkpoints.pop(task_id, None)
    
    # =========================================================================
    # DIAGNOSTICS
    # =========================================================================
    
    def _save_failure(self, failure: Failure):
        """Save failure to Milvus for diagnostics"""
        if self.milvus:
            self.milvus.insert("diagnostics", {
                "id": failure.id,
                "failure_type": failure.failure_type.value,
                "message": failure.message,
                "context_json": str(failure.context),
                "timestamp": int(failure.timestamp),
                "stack_trace": failure.stack_trace or "",
                "recoverable": failure.recoverable,
                "recovery_attempts": failure.recovery_attempts,
            })
    
    def get_diagnostics(self, service_name: str = None) -> Dict:
        """Get diagnostic summary"""
        relevant = self.failures
        if service_name:
            relevant = [f for f in self.failures if f.context.get("service") == service_name]
        
        return {
            "total_failures": len(relevant),
            "by_type": self._count_by_type(relevant),
            "circuit_breakers": {
                name: cb.get_state()
                for name, cb in self.circuit_breakers.items()
            },
            "recent_failures": [
                {
                    "type": f.failure_type.value,
                    "message": f.message,
                    "time": f.timestamp,
                    "attempts": f.recovery_attempts,
                }
                for f in relevant[-10:]
            ],
            "checkpoints": len(self.checkpoints),
        }
    
    def _count_by_type(self, failures: List[Failure]) -> Dict[str, int]:
        """Count failures by type"""
        counts = {}
        for f in failures:
            key = f.failure_type.value
            counts[key] = counts.get(key, 0) + 1
        return counts
    
    def reset_circuit_breaker(self, service_name: str):
        """Manually reset a circuit breaker"""
        if service_name in self.circuit_breakers:
            cb = self.circuit_breakers[service_name]
            cb.failures = 0
            cb.state = "CLOSED"
            logger.info(f"Reset circuit breaker: {service_name}")
    
    def get_stats(self) -> Dict:
        """Get recovery engine statistics"""
        return {
            "total_failures": len(self.failures),
            "circuit_breakers": len(self.circuit_breakers),
            "open_circuits": sum(
                1 for cb in self.circuit_breakers.values()
                if cb.state == "OPEN"
            ),
            "checkpoints": len(self.checkpoints),
            "failure_rate_last_hour": self._calculate_failure_rate(3600),
        }
    
    def _calculate_failure_rate(self, window_seconds: int) -> float:
        """Calculate failure rate in time window"""
        now = time.time()
        recent = [f for f in self.failures if now - f.timestamp < window_seconds]
        return len(recent) / (window_seconds / 60)  # Failures per minute
