"""
Sadhaka (साधक) - Configuration
The one who accomplishes.
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, List
from enum import Enum


class ContainerLifecycle(Enum):
    EPHEMERAL = "ephemeral"
    PERSISTENT = "persistent"


class HealthStatus(Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    DEPRECATED = "deprecated"
    ARCHIVED = "archived"


class GoalStatus(Enum):
    PENDING = "pending"
    ACTIVE = "active"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"


class FailureType(Enum):
    TIMEOUT = "timeout"
    TOOL_ERROR = "tool_error"
    LLM_ERROR = "llm_error"
    VALIDATION_ERROR = "validation_error"
    RESOURCE_ERROR = "resource_error"
    DOCKER_ERROR = "docker_error"
    MCP_ERROR = "mcp_error"
    UNKNOWN = "unknown"


@dataclass
class VLLMConfig:
    """vLLM server configuration"""
    model: str = "Qwen/Qwen2.5-7B-Instruct"
    tensor_parallel_size: int = 1
    gpu_memory_utilization: float = 0.9
    max_model_len: int = 32768
    max_num_seqs: int = 256
    enable_prefix_caching: bool = True
    enable_chunked_prefill: bool = True


@dataclass
class MilvusConfig:
    """Milvus configuration"""
    uri: str = "http://localhost:19530"
    db_name: str = "sadhaka"
    embedding_dim: int = 1024


@dataclass
class DockerConfig:
    """Docker runtime configuration"""
    workspace_dir: str = "/tmp/sadhaka"
    default_memory_limit: str = "512m"
    default_cpu_quota: int = 50000
    default_timeout: int = 60
    health_check_interval: int = 30


@dataclass
class RecoveryConfig:
    """Recovery engine configuration"""
    max_retries: int = 3
    backoff_base: float = 2.0
    backoff_max: float = 60.0
    circuit_breaker_threshold: int = 5
    circuit_breaker_recovery_timeout: float = 30.0


@dataclass
class SadhakaConfig:
    """Main Sadhaka configuration"""
    vllm: VLLMConfig = field(default_factory=VLLMConfig)
    milvus: MilvusConfig = field(default_factory=MilvusConfig)
    docker: DockerConfig = field(default_factory=DockerConfig)
    recovery: RecoveryConfig = field(default_factory=RecoveryConfig)
    
    system_prompt: str = """You are a Sadhaka agent - one who accomplishes tasks through structured reasoning.

You work collaboratively with other agents via a shared blackboard.
Read the blackboard state to understand current progress.
Write your outputs to the blackboard for other agents.
Use tools when needed. Follow goals precisely.

Format your responses as:
Thought: [your reasoning]
Action: [action_name]
Action Input: [input as JSON]

Or for final answers:
Thought: [reasoning]
Final Answer: [your answer]
"""


DEFAULT_CONFIG = SadhakaConfig()
