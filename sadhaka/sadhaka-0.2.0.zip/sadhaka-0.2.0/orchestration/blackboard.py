"""
Sadhaka Blackboard - Shared state for agent coordination

Agents don't pass strings to each other directly.
They read/write state to the blackboard.
Other agents react to state changes.
"""

import asyncio
import json
import time
import uuid
import logging
from typing import Optional, Dict, List, Callable, Any
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class BlackboardEntry:
    """A single entry on the blackboard"""
    key: str
    value: Any
    written_by: str
    written_at: float
    version: int


class Blackboard:
    """
    Shared state for agent coordination.
    
    Features:
    - Key-value storage with versioning
    - Watch mechanism for reactive updates
    - Wait-for blocking reads
    - Persistence to Milvus
    """
    
    def __init__(self, milvus_client, task_id: str):
        self.milvus = milvus_client
        self.task_id = task_id
        self._local_cache: Dict[str, BlackboardEntry] = {}
        self._watchers: Dict[str, List[Callable]] = {}
        self._lock = asyncio.Lock() if asyncio else None
    
    async def write(
        self,
        key: str,
        value: Any,
        agent_id: str,
    ) -> BlackboardEntry:
        """Write a value to the blackboard"""
        # Get current version
        existing = self._local_cache.get(key)
        version = (existing.version + 1) if existing else 1
        
        entry = BlackboardEntry(
            key=key,
            value=value,
            written_by=agent_id,
            written_at=time.time(),
            version=version,
        )
        
        self._local_cache[key] = entry
        
        # Persist to Milvus
        await self._persist_state()
        
        # Notify watchers
        await self._notify_watchers(key, entry)
        
        logger.debug(f"Blackboard write: {key} by {agent_id} (v{version})")
        return entry
    
    def write_sync(self, key: str, value: Any, agent_id: str) -> BlackboardEntry:
        """Synchronous write for non-async contexts"""
        existing = self._local_cache.get(key)
        version = (existing.version + 1) if existing else 1
        
        entry = BlackboardEntry(
            key=key,
            value=value,
            written_by=agent_id,
            written_at=time.time(),
            version=version,
        )
        
        self._local_cache[key] = entry
        self._persist_state_sync()
        
        logger.debug(f"Blackboard write: {key} by {agent_id} (v{version})")
        return entry
    
    async def read(self, key: str) -> Optional[Any]:
        """Read a value from the blackboard"""
        entry = self._local_cache.get(key)
        return entry.value if entry else None
    
    def read_sync(self, key: str) -> Optional[Any]:
        """Synchronous read"""
        entry = self._local_cache.get(key)
        return entry.value if entry else None
    
    async def read_entry(self, key: str) -> Optional[BlackboardEntry]:
        """Read full entry including metadata"""
        return self._local_cache.get(key)
    
    async def read_all(self) -> Dict[str, Any]:
        """Read all values"""
        return {k: v.value for k, v in self._local_cache.items()}
    
    def read_all_sync(self) -> Dict[str, Any]:
        """Synchronous read all"""
        return {k: v.value for k, v in self._local_cache.items()}
    
    async def delete(self, key: str, agent_id: str) -> bool:
        """Delete a key from the blackboard"""
        if key in self._local_cache:
            del self._local_cache[key]
            await self._persist_state()
            logger.debug(f"Blackboard delete: {key} by {agent_id}")
            return True
        return False
    
    def watch(self, key: str, callback: Callable):
        """
        Watch a key for changes.
        
        Callback signature: async def callback(entry: BlackboardEntry)
        """
        if key not in self._watchers:
            self._watchers[key] = []
        self._watchers[key].append(callback)
    
    def unwatch(self, key: str, callback: Callable):
        """Remove a watcher"""
        if key in self._watchers:
            try:
                self._watchers[key].remove(callback)
            except ValueError:
                pass
    
    async def _notify_watchers(self, key: str, entry: BlackboardEntry):
        """Notify all watchers of a key change"""
        if key in self._watchers:
            for callback in self._watchers[key]:
                try:
                    if asyncio.iscoroutinefunction(callback):
                        await callback(entry)
                    else:
                        callback(entry)
                except Exception as e:
                    logger.error(f"Watcher callback failed: {e}")
        
        # Also notify wildcard watchers
        if "*" in self._watchers:
            for callback in self._watchers["*"]:
                try:
                    if asyncio.iscoroutinefunction(callback):
                        await callback(entry)
                    else:
                        callback(entry)
                except Exception as e:
                    logger.error(f"Wildcard watcher callback failed: {e}")
    
    async def wait_for(
        self,
        key: str,
        timeout: float = 60.0,
        condition: Optional[Callable] = None,
    ) -> Optional[Any]:
        """
        Wait for a key to be written.
        
        Args:
            key: Key to wait for
            timeout: Maximum wait time in seconds
            condition: Optional function to check value (value) -> bool
        
        Returns:
            Value when available, or None on timeout
        """
        event = asyncio.Event()
        result = [None]
        
        async def on_change(entry: BlackboardEntry):
            if condition is None or condition(entry.value):
                result[0] = entry.value
                event.set()
        
        self.watch(key, on_change)
        
        # Check if already exists
        existing = await self.read(key)
        if existing is not None:
            if condition is None or condition(existing):
                self.unwatch(key, on_change)
                return existing
        
        try:
            await asyncio.wait_for(event.wait(), timeout=timeout)
            return result[0]
        except asyncio.TimeoutError:
            return None
        finally:
            self.unwatch(key, on_change)
    
    async def _persist_state(self):
        """Persist current state to Milvus"""
        state_json = json.dumps({
            k: {
                "value": v.value,
                "written_by": v.written_by,
                "written_at": v.written_at,
                "version": v.version,
            }
            for k, v in self._local_cache.items()
        }, default=str)
        
        self.milvus.upsert("task_state", {
            "id": self.task_id,
            "task_id": self.task_id,
            "intermediate_json": state_json,
            "updated_at": int(time.time()),
        })
    
    def _persist_state_sync(self):
        """Synchronous persist"""
        state_json = json.dumps({
            k: {
                "value": v.value,
                "written_by": v.written_by,
                "written_at": v.written_at,
                "version": v.version,
            }
            for k, v in self._local_cache.items()
        }, default=str)
        
        self.milvus.upsert("task_state", {
            "id": self.task_id,
            "task_id": self.task_id,
            "intermediate_json": state_json,
            "updated_at": int(time.time()),
        })
    
    async def load_from_milvus(self):
        """Load state from Milvus (for recovery)"""
        result = self.milvus.get("task_state", self.task_id)
        if result and result.get("intermediate_json"):
            try:
                data = json.loads(result["intermediate_json"])
                for key, entry_data in data.items():
                    self._local_cache[key] = BlackboardEntry(
                        key=key,
                        value=entry_data["value"],
                        written_by=entry_data["written_by"],
                        written_at=entry_data["written_at"],
                        version=entry_data["version"],
                    )
                logger.info(f"Loaded {len(self._local_cache)} entries from Milvus")
            except json.JSONDecodeError as e:
                logger.error(f"Failed to parse blackboard state: {e}")
    
    def load_from_milvus_sync(self):
        """Synchronous load"""
        result = self.milvus.get("task_state", self.task_id)
        if result and result.get("intermediate_json"):
            try:
                data = json.loads(result["intermediate_json"])
                for key, entry_data in data.items():
                    self._local_cache[key] = BlackboardEntry(
                        key=key,
                        value=entry_data["value"],
                        written_by=entry_data["written_by"],
                        written_at=entry_data["written_at"],
                        version=entry_data["version"],
                    )
            except json.JSONDecodeError as e:
                logger.error(f"Failed to parse blackboard state: {e}")
    
    def get_history(self, key: str) -> List[Dict]:
        """Get version history for a key (from current session only)"""
        entry = self._local_cache.get(key)
        if entry:
            return [{
                "version": entry.version,
                "value": entry.value,
                "written_by": entry.written_by,
                "written_at": entry.written_at,
            }]
        return []
    
    def get_contributors(self) -> List[str]:
        """Get list of agents that have written to this blackboard"""
        return list(set(e.written_by for e in self._local_cache.values()))
    
    def get_stats(self) -> Dict:
        """Get blackboard statistics"""
        return {
            "task_id": self.task_id,
            "entry_count": len(self._local_cache),
            "contributors": self.get_contributors(),
            "watcher_count": sum(len(w) for w in self._watchers.values()),
            "keys": list(self._local_cache.keys()),
        }
