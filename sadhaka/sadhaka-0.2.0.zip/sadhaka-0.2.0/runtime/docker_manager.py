"""
Sadhaka Docker Manager - Container lifecycle management

Two lifecycles:
- EPHEMERAL: Run once, destroy (for testing/thinking)
- PERSISTENT: Long-running, monitored (for deployed tools/MCP servers)
"""

import asyncio
import time
import uuid
import logging
import shutil
import subprocess
from pathlib import Path
from typing import Optional, Dict, List
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)


class ContainerLifecycle(Enum):
    EPHEMERAL = "ephemeral"
    PERSISTENT = "persistent"


class ContainerStatus(Enum):
    PENDING = "pending"
    STARTING = "starting"
    RUNNING = "running"
    STOPPING = "stopping"
    STOPPED = "stopped"
    ERROR = "error"


@dataclass
class ContainerSpec:
    """Specification for creating a container"""
    name: str
    lifecycle: ContainerLifecycle = ContainerLifecycle.EPHEMERAL
    image: str = "python:3.11-slim"
    command: Optional[str] = None
    code: Optional[str] = None
    environment: Dict[str, str] = field(default_factory=dict)
    memory_limit: str = "512m"
    cpu_quota: int = 50000
    network_enabled: bool = False
    ports: Dict[int, int] = field(default_factory=dict)
    volumes: Dict[str, str] = field(default_factory=dict)
    timeout: int = 60


@dataclass
class ContainerInfo:
    """Runtime info for a container"""
    id: str
    name: str
    lifecycle: ContainerLifecycle
    status: ContainerStatus
    container_id: Optional[str] = None
    started_at: Optional[float] = None
    health_checks: int = 0
    last_health_check: Optional[float] = None


@dataclass
class ExecutionResult:
    """Result from code execution"""
    success: bool
    stdout: str
    stderr: str
    exit_code: int
    execution_time_ms: int


class DockerManager:
    """
    Manages Docker containers with two lifecycles.
    
    EPHEMERAL:
    - For testing, thinking, one-off code execution
    - Spin up → Run → Capture output → Destroy
    - No state persistence
    - Strict resource limits and timeouts
    
    PERSISTENT:
    - For deployed MCP servers, long-running tools
    - Start → Health check → Keep alive → Graceful shutdown
    - State persisted via volumes
    - Monitored and auto-restarted if unhealthy
    """
    
    IMAGES = {
        "python": "python:3.11-slim",
        "node": "node:20-slim",
        "sandbox": "python:3.11-slim",
    }
    
    def __init__(self, workspace_dir: str = "/tmp/sadhaka"):
        self.workspace = Path(workspace_dir)
        self.workspace.mkdir(parents=True, exist_ok=True)
        
        self._docker_available = False
        self._client = None
        
        # Track containers
        self.ephemeral_containers: Dict[str, ContainerInfo] = {}
        self.persistent_containers: Dict[str, ContainerInfo] = {}
        
        self._health_check_task = None
        
        self._check_docker()
    
    def _check_docker(self):
        """Check if Docker is available"""
        try:
            import docker
            self._client = docker.from_env()
            self._client.ping()
            self._docker_available = True
            logger.info("Docker available")
        except Exception as e:
            logger.warning(f"Docker not available: {e}. Using subprocess fallback.")
            self._docker_available = False
    
    # =========================================================================
    # EPHEMERAL CONTAINERS - Think/Test/Execute
    # =========================================================================
    
    async def run_ephemeral(
        self,
        code: str,
        spec: Optional[ContainerSpec] = None,
    ) -> ExecutionResult:
        """
        Run code in ephemeral container or subprocess.
        
        Container/process is created, code runs, output captured, then destroyed.
        Used for: testing tools, running experiments, validating code.
        """
        spec = spec or ContainerSpec(
            name=f"ephemeral_{uuid.uuid4().hex[:8]}",
            lifecycle=ContainerLifecycle.EPHEMERAL,
        )
        
        if self._docker_available:
            return await self._run_ephemeral_docker(code, spec)
        else:
            return await self._run_ephemeral_subprocess(code, spec)
    
    async def _run_ephemeral_docker(self, code: str, spec: ContainerSpec) -> ExecutionResult:
        """Run in Docker container"""
        container_id = f"sadhaka_eph_{uuid.uuid4().hex[:8]}"
        
        # Create temp directory for code
        code_dir = self.workspace / container_id
        code_dir.mkdir(parents=True, exist_ok=True)
        
        code_file = code_dir / "main.py"
        code_file.write_text(code)
        
        start_time = time.time()
        
        try:
            container = self._client.containers.run(
                spec.image,
                command=spec.command or "python /code/main.py",
                name=container_id,
                volumes={str(code_dir): {"bind": "/code", "mode": "ro"}},
                mem_limit=spec.memory_limit,
                cpu_quota=spec.cpu_quota,
                network_disabled=not spec.network_enabled,
                environment=spec.environment,
                detach=True,
                remove=False,
            )
            
            # Wait with timeout
            try:
                result = container.wait(timeout=spec.timeout)
                exit_code = result["StatusCode"]
            except Exception:
                logger.warning(f"Container {container_id} timed out")
                container.kill()
                exit_code = -1
            
            stdout = container.logs(stdout=True, stderr=False).decode()
            stderr = container.logs(stdout=False, stderr=True).decode()
            
            execution_time_ms = int((time.time() - start_time) * 1000)
            
            return ExecutionResult(
                success=exit_code == 0,
                stdout=stdout,
                stderr=stderr,
                exit_code=exit_code,
                execution_time_ms=execution_time_ms,
            )
            
        except Exception as e:
            logger.error(f"Docker execution failed: {e}")
            return ExecutionResult(
                success=False,
                stdout="",
                stderr=str(e),
                exit_code=-1,
                execution_time_ms=int((time.time() - start_time) * 1000),
            )
            
        finally:
            # Cleanup
            await self._cleanup_ephemeral(container_id, code_dir)
    
    async def _run_ephemeral_subprocess(self, code: str, spec: ContainerSpec) -> ExecutionResult:
        """Fallback: Run in subprocess (less isolated)"""
        container_id = f"sadhaka_sub_{uuid.uuid4().hex[:8]}"
        
        # Create temp directory
        code_dir = self.workspace / container_id
        code_dir.mkdir(parents=True, exist_ok=True)
        
        code_file = code_dir / "main.py"
        code_file.write_text(code)
        
        start_time = time.time()
        
        try:
            process = await asyncio.create_subprocess_exec(
                "python", str(code_file),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(code_dir),
            )
            
            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    process.communicate(),
                    timeout=spec.timeout,
                )
                exit_code = process.returncode
            except asyncio.TimeoutError:
                process.kill()
                stdout_bytes, stderr_bytes = b"", b"Timeout exceeded"
                exit_code = -1
            
            execution_time_ms = int((time.time() - start_time) * 1000)
            
            return ExecutionResult(
                success=exit_code == 0,
                stdout=stdout_bytes.decode(),
                stderr=stderr_bytes.decode(),
                exit_code=exit_code,
                execution_time_ms=execution_time_ms,
            )
            
        except Exception as e:
            return ExecutionResult(
                success=False,
                stdout="",
                stderr=str(e),
                exit_code=-1,
                execution_time_ms=int((time.time() - start_time) * 1000),
            )
            
        finally:
            # Cleanup
            try:
                shutil.rmtree(code_dir, ignore_errors=True)
            except Exception:
                pass
    
    async def _cleanup_ephemeral(self, container_id: str, code_dir: Path):
        """Clean up ephemeral container and temp files"""
        if self._docker_available:
            try:
                container = self._client.containers.get(container_id)
                container.remove(force=True)
            except Exception:
                pass
        
        try:
            shutil.rmtree(code_dir, ignore_errors=True)
        except Exception:
            pass
    
    # =========================================================================
    # PERSISTENT CONTAINERS - Deploy/Serve
    # =========================================================================
    
    async def start_persistent(self, spec: ContainerSpec) -> ContainerInfo:
        """
        Start a persistent container.
        
        Used for: MCP servers, deployed tools, long-running services.
        """
        if spec.lifecycle != ContainerLifecycle.PERSISTENT:
            spec.lifecycle = ContainerLifecycle.PERSISTENT
        
        container_id = f"sadhaka_per_{spec.name}_{uuid.uuid4().hex[:8]}"
        
        info = ContainerInfo(
            id=container_id,
            name=spec.name,
            lifecycle=ContainerLifecycle.PERSISTENT,
            status=ContainerStatus.STARTING,
        )
        
        if not self._docker_available:
            logger.warning("Docker not available, persistent containers not supported")
            info.status = ContainerStatus.ERROR
            return info
        
        # Create workspace for this service
        service_dir = self.workspace / "persistent" / spec.name
        service_dir.mkdir(parents=True, exist_ok=True)
        
        # Write code if provided
        if spec.code:
            code_file = service_dir / "main.py"
            code_file.write_text(spec.code)
        
        # Build volumes
        volumes = {str(service_dir): {"bind": "/app", "mode": "rw"}}
        volumes.update({
            host: {"bind": container, "mode": "rw"}
            for host, container in spec.volumes.items()
        })
        
        try:
            container = self._client.containers.run(
                spec.image,
                command=spec.command or "python /app/main.py",
                name=container_id,
                volumes=volumes,
                ports={f"{p}/tcp": h for p, h in spec.ports.items()},
                mem_limit=spec.memory_limit,
                cpu_quota=spec.cpu_quota,
                network_disabled=not spec.network_enabled,
                environment=spec.environment,
                detach=True,
                restart_policy={"Name": "on-failure", "MaximumRetryCount": 3},
            )
            
            info.container_id = container.id
            info.status = ContainerStatus.RUNNING
            info.started_at = time.time()
            
            self.persistent_containers[container_id] = info
            
            logger.info(f"Started persistent container {container_id}")
            return info
            
        except Exception as e:
            logger.error(f"Failed to start persistent container: {e}")
            info.status = ContainerStatus.ERROR
            return info
    
    async def stop_persistent(self, container_id: str, timeout: int = 10) -> bool:
        """Gracefully stop a persistent container"""
        info = self.persistent_containers.get(container_id)
        if not info:
            return False
        
        if not self._docker_available:
            return False
        
        info.status = ContainerStatus.STOPPING
        
        try:
            container = self._client.containers.get(info.container_id)
            container.stop(timeout=timeout)
            container.remove()
            
            info.status = ContainerStatus.STOPPED
            del self.persistent_containers[container_id]
            
            logger.info(f"Stopped persistent container {container_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to stop container {container_id}: {e}")
            info.status = ContainerStatus.ERROR
            return False
    
    async def restart_persistent(self, container_id: str) -> bool:
        """Restart a persistent container"""
        info = self.persistent_containers.get(container_id)
        if not info or not self._docker_available:
            return False
        
        try:
            container = self._client.containers.get(info.container_id)
            container.restart(timeout=10)
            
            info.status = ContainerStatus.RUNNING
            info.started_at = time.time()
            
            logger.info(f"Restarted persistent container {container_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to restart container {container_id}: {e}")
            info.status = ContainerStatus.ERROR
            return False
    
    # =========================================================================
    # HEALTH MONITORING
    # =========================================================================
    
    async def health_check(self, container_id: str) -> Dict:
        """Check health of a persistent container"""
        info = self.persistent_containers.get(container_id)
        if not info:
            return {"healthy": False, "reason": "Container not found"}
        
        if not self._docker_available:
            return {"healthy": False, "reason": "Docker not available"}
        
        try:
            container = self._client.containers.get(info.container_id)
            container.reload()
            
            status = container.status
            
            info.health_checks += 1
            info.last_health_check = time.time()
            
            if status == "running":
                info.status = ContainerStatus.RUNNING
                return {
                    "healthy": True,
                    "status": status,
                    "uptime": time.time() - info.started_at if info.started_at else 0,
                    "health_checks": info.health_checks,
                }
            else:
                info.status = ContainerStatus.ERROR
                return {
                    "healthy": False,
                    "status": status,
                    "reason": f"Container status: {status}",
                }
                
        except Exception as e:
            info.status = ContainerStatus.ERROR
            return {"healthy": False, "reason": str(e)}
    
    async def start_health_monitor(self, interval: int = 30):
        """Start background health monitoring"""
        async def monitor():
            while True:
                for container_id in list(self.persistent_containers.keys()):
                    health = await self.health_check(container_id)
                    
                    if not health["healthy"]:
                        logger.warning(f"Container {container_id} unhealthy: {health}")
                        await self.restart_persistent(container_id)
                
                await asyncio.sleep(interval)
        
        self._health_check_task = asyncio.create_task(monitor())
    
    async def stop_health_monitor(self):
        """Stop background health monitoring"""
        if self._health_check_task:
            self._health_check_task.cancel()
            self._health_check_task = None
    
    # =========================================================================
    # EXEC IN PERSISTENT
    # =========================================================================
    
    async def exec_in_persistent(
        self,
        container_id: str,
        command: str,
        timeout: int = 30,
    ) -> ExecutionResult:
        """Execute command in existing persistent container"""
        info = self.persistent_containers.get(container_id)
        if not info or info.status != ContainerStatus.RUNNING:
            return ExecutionResult(
                success=False,
                stdout="",
                stderr="Container not running",
                exit_code=-1,
                execution_time_ms=0,
            )
        
        if not self._docker_available:
            return ExecutionResult(
                success=False,
                stdout="",
                stderr="Docker not available",
                exit_code=-1,
                execution_time_ms=0,
            )
        
        start_time = time.time()
        
        try:
            container = self._client.containers.get(info.container_id)
            exit_code, output = container.exec_run(command, demux=True)
            
            stdout = output[0].decode() if output[0] else ""
            stderr = output[1].decode() if output[1] else ""
            
            return ExecutionResult(
                success=exit_code == 0,
                stdout=stdout,
                stderr=stderr,
                exit_code=exit_code,
                execution_time_ms=int((time.time() - start_time) * 1000),
            )
            
        except Exception as e:
            return ExecutionResult(
                success=False,
                stdout="",
                stderr=str(e),
                exit_code=-1,
                execution_time_ms=int((time.time() - start_time) * 1000),
            )
    
    # =========================================================================
    # CLEANUP
    # =========================================================================
    
    async def cleanup_all(self):
        """Stop all containers and cleanup"""
        await self.stop_health_monitor()
        
        # Stop all persistent containers
        for container_id in list(self.persistent_containers.keys()):
            await self.stop_persistent(container_id)
        
        # Cleanup orphaned containers
        if self._docker_available:
            try:
                containers = self._client.containers.list(
                    all=True,
                    filters={"name": "sadhaka_"}
                )
                for container in containers:
                    try:
                        container.remove(force=True)
                    except Exception:
                        pass
            except Exception as e:
                logger.error(f"Cleanup failed: {e}")
    
    def get_stats(self) -> Dict:
        """Get container statistics"""
        return {
            "docker_available": self._docker_available,
            "workspace": str(self.workspace),
            "ephemeral_count": len(self.ephemeral_containers),
            "persistent_count": len(self.persistent_containers),
            "persistent_running": sum(
                1 for c in self.persistent_containers.values()
                if c.status == ContainerStatus.RUNNING
            ),
            "containers": [
                {
                    "id": info.id,
                    "name": info.name,
                    "lifecycle": info.lifecycle.value,
                    "status": info.status.value,
                    "uptime": time.time() - info.started_at if info.started_at else 0,
                }
                for info in self.persistent_containers.values()
            ]
        }
    
    def is_available(self) -> bool:
        """Check if Docker is available"""
        return self._docker_available
