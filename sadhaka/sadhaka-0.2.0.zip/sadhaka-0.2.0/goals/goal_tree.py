"""
Sadhaka Goal Tree - Hierarchical goal definitions and tracking

Pillar 3: Specific Goal Definition
"Precise goals anchor reasoning — vague instructions create wandering behavior"
"""

import time
import json
import uuid
import logging
from typing import Optional, Dict, List
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)


class GoalStatus(Enum):
    PENDING = "pending"
    ACTIVE = "active"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"


@dataclass
class Goal:
    """
    Precise, measurable goal with success criteria.
    
    Good goal: "Calculate average sales per region from sales.csv, output as JSON"
    Bad goal: "Help with data analysis"
    """
    id: str
    description: str
    success_criteria: List[str]
    input_spec: Dict
    output_spec: Dict
    constraints: List[str] = field(default_factory=list)
    parent_id: Optional[str] = None
    children_ids: List[str] = field(default_factory=list)
    status: GoalStatus = GoalStatus.PENDING
    progress: float = 0.0
    assigned_agent_id: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None


class GoalTree:
    """
    Hierarchical goal decomposition and tracking.
    
    Root goal decomposes into sub-goals.
    Each sub-goal has explicit success criteria.
    Progress bubbles up from leaves to root.
    """
    
    def __init__(self, milvus_client=None):
        self.milvus = milvus_client
        self.goals: Dict[str, Goal] = {}
    
    def create_root_goal(
        self,
        task_id: str,
        description: str,
        success_criteria: List[str],
        input_spec: Dict = None,
        output_spec: Dict = None,
        constraints: List[str] = None,
    ) -> Goal:
        """Create the root goal for a task"""
        goal = Goal(
            id=f"goal_{task_id}_{uuid.uuid4().hex[:8]}",
            description=description,
            success_criteria=success_criteria,
            input_spec=input_spec or {},
            output_spec=output_spec or {},
            constraints=constraints or [],
            status=GoalStatus.ACTIVE,
        )
        
        self.goals[goal.id] = goal
        self._save_to_milvus(goal)
        
        logger.info(f"Created root goal: {goal.id}")
        return goal
    
    def decompose_goal(
        self,
        parent_id: str,
        sub_goals: List[Dict],
    ) -> List[Goal]:
        """
        Decompose a goal into sub-goals.
        
        Each sub-goal must be:
        - Specific (clear description)
        - Measurable (success_criteria)
        - Achievable (has required inputs)
        - Relevant (contributes to parent)
        """
        parent = self.goals.get(parent_id)
        if not parent:
            raise ValueError(f"Parent goal {parent_id} not found")
        
        children = []
        for sg in sub_goals:
            child = Goal(
                id=f"goal_{uuid.uuid4().hex[:8]}",
                description=sg["description"],
                success_criteria=sg.get("success_criteria", []),
                input_spec=sg.get("input_spec", {}),
                output_spec=sg.get("output_spec", {}),
                constraints=sg.get("constraints", []),
                parent_id=parent_id,
                status=GoalStatus.PENDING,
            )
            
            self.goals[child.id] = child
            parent.children_ids.append(child.id)
            children.append(child)
            self._save_to_milvus(child)
        
        self._save_to_milvus(parent)
        logger.info(f"Decomposed goal {parent_id} into {len(children)} sub-goals")
        
        return children
    
    def activate_goal(self, goal_id: str, agent_id: str = None):
        """Mark a goal as active and optionally assign an agent"""
        goal = self.goals.get(goal_id)
        if goal:
            goal.status = GoalStatus.ACTIVE
            if agent_id:
                goal.assigned_agent_id = agent_id
            self._save_to_milvus(goal)
    
    def complete_goal(self, goal_id: str):
        """Mark a goal as completed"""
        goal = self.goals.get(goal_id)
        if goal:
            goal.status = GoalStatus.COMPLETED
            goal.progress = 1.0
            goal.completed_at = time.time()
            self._save_to_milvus(goal)
            
            # Update parent progress
            if goal.parent_id:
                self._update_parent_progress(goal.parent_id)
    
    def fail_goal(self, goal_id: str, reason: str = None):
        """Mark a goal as failed"""
        goal = self.goals.get(goal_id)
        if goal:
            goal.status = GoalStatus.FAILED
            goal.completed_at = time.time()
            self._save_to_milvus(goal)
            
            # Block parent if this was required
            if goal.parent_id:
                parent = self.goals.get(goal.parent_id)
                if parent:
                    parent.status = GoalStatus.BLOCKED
                    self._save_to_milvus(parent)
    
    def update_progress(self, goal_id: str, progress: float):
        """Update goal progress (0.0 to 1.0)"""
        goal = self.goals.get(goal_id)
        if goal:
            goal.progress = max(0.0, min(1.0, progress))
            
            if goal.progress >= 1.0:
                goal.status = GoalStatus.COMPLETED
                goal.completed_at = time.time()
            
            self._save_to_milvus(goal)
            
            # Update parent
            if goal.parent_id:
                self._update_parent_progress(goal.parent_id)
    
    def _update_parent_progress(self, parent_id: str):
        """Calculate parent progress from children"""
        parent = self.goals.get(parent_id)
        if not parent or not parent.children_ids:
            return
        
        children = [self.goals[cid] for cid in parent.children_ids if cid in self.goals]
        if not children:
            return
        
        # Average progress of children
        parent.progress = sum(c.progress for c in children) / len(children)
        
        # Update status
        if all(c.status == GoalStatus.COMPLETED for c in children):
            parent.status = GoalStatus.COMPLETED
            parent.completed_at = time.time()
        elif any(c.status == GoalStatus.FAILED for c in children):
            parent.status = GoalStatus.BLOCKED
        elif any(c.status == GoalStatus.ACTIVE for c in children):
            parent.status = GoalStatus.ACTIVE
        
        self._save_to_milvus(parent)
        
        # Recurse up
        if parent.parent_id:
            self._update_parent_progress(parent.parent_id)
    
    def check_alignment(self, goal_id: str, current_action: str) -> Dict:
        """
        Check if current action aligns with goal.
        
        Returns alignment assessment.
        """
        goal = self.goals.get(goal_id)
        if not goal:
            return {"aligned": False, "score": 0, "reason": "Goal not found"}
        
        # Simple keyword matching for alignment
        action_lower = current_action.lower()
        desc_lower = goal.description.lower()
        
        # Check for keyword overlap
        action_words = set(action_lower.split())
        goal_words = set(desc_lower.split())
        overlap = len(action_words & goal_words)
        
        # Check constraints
        constraint_violations = []
        for constraint in goal.constraints:
            if constraint.lower() in action_lower:
                constraint_violations.append(constraint)
        
        # Calculate alignment score
        if overlap > 3:
            score = 0.8
        elif overlap > 1:
            score = 0.5
        else:
            score = 0.2
        
        if constraint_violations:
            score -= 0.3 * len(constraint_violations)
        
        score = max(0.0, min(1.0, score))
        
        return {
            "aligned": score > 0.5,
            "score": score,
            "reason": f"Keyword overlap: {overlap}, Constraint violations: {len(constraint_violations)}",
            "constraint_violations": constraint_violations,
            "suggestion": "" if score > 0.5 else "Consider revising action to better match goal",
        }
    
    def get_goal(self, goal_id: str) -> Optional[Goal]:
        """Get a goal by ID"""
        return self.goals.get(goal_id)
    
    def get_goal_path(self, goal_id: str) -> List[Goal]:
        """Get path from root to this goal"""
        path = []
        current = self.goals.get(goal_id)
        
        while current:
            path.insert(0, current)
            current = self.goals.get(current.parent_id) if current.parent_id else None
        
        return path
    
    def get_active_goals(self) -> List[Goal]:
        """Get all active goals"""
        return [g for g in self.goals.values() if g.status == GoalStatus.ACTIVE]
    
    def get_pending_goals(self) -> List[Goal]:
        """Get all pending goals (ready to start)"""
        return [g for g in self.goals.values() if g.status == GoalStatus.PENDING]
    
    def get_tree_summary(self, root_id: str = None) -> Dict:
        """Get summary of goal tree"""
        if root_id:
            goals = self._get_subtree(root_id)
        else:
            goals = list(self.goals.values())
        
        return {
            "total_goals": len(goals),
            "completed": sum(1 for g in goals if g.status == GoalStatus.COMPLETED),
            "active": sum(1 for g in goals if g.status == GoalStatus.ACTIVE),
            "pending": sum(1 for g in goals if g.status == GoalStatus.PENDING),
            "failed": sum(1 for g in goals if g.status == GoalStatus.FAILED),
            "blocked": sum(1 for g in goals if g.status == GoalStatus.BLOCKED),
            "overall_progress": sum(g.progress for g in goals) / len(goals) if goals else 0,
        }
    
    def _get_subtree(self, goal_id: str) -> List[Goal]:
        """Get all goals in subtree rooted at goal_id"""
        result = []
        goal = self.goals.get(goal_id)
        if not goal:
            return result
        
        result.append(goal)
        for child_id in goal.children_ids:
            result.extend(self._get_subtree(child_id))
        
        return result
    
    def _save_to_milvus(self, goal: Goal):
        """Persist goal to Milvus"""
        if not self.milvus:
            return
        
        self.milvus.upsert("goals", {
            "id": goal.id,
            "task_id": goal.id.split("_")[1] if "_" in goal.id else "",
            "description": goal.description,
            "success_criteria_json": json.dumps(goal.success_criteria),
            "input_spec_json": json.dumps(goal.input_spec),
            "output_spec_json": json.dumps(goal.output_spec),
            "constraints_json": json.dumps(goal.constraints),
            "parent_id": goal.parent_id or "",
            "children_ids_json": json.dumps(goal.children_ids),
            "status": goal.status.value,
            "progress": goal.progress,
            "assigned_agent_id": goal.assigned_agent_id or "",
            "created_at": int(goal.created_at),
            "completed_at": int(goal.completed_at) if goal.completed_at else 0,
            "embedding": [0.0] * 1024,  # Placeholder
        })
    
    def to_dict(self, goal_id: str) -> Dict:
        """Convert goal to dictionary"""
        goal = self.goals.get(goal_id)
        if not goal:
            return {}
        
        return {
            "id": goal.id,
            "description": goal.description,
            "success_criteria": goal.success_criteria,
            "input_spec": goal.input_spec,
            "output_spec": goal.output_spec,
            "constraints": goal.constraints,
            "status": goal.status.value,
            "progress": goal.progress,
            "assigned_agent_id": goal.assigned_agent_id,
            "children": [self.to_dict(cid) for cid in goal.children_ids],
        }
