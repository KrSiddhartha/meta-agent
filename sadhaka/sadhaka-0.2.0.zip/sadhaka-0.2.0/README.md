# Sadhaka (साधक) v0.2.0

**"The one who accomplishes"** - A production-grade AI agent framework.

## Quick Start

```bash
# Install
pip install -e .

# Or with all dependencies
pip install -e ".[full]"
```

```python
from sadhaka import __version__
print(f"Sadhaka v{__version__}")

# Use components directly
from sadhaka.core.tools import ToolRegistry
from sadhaka.core.tracing import Tracer
from sadhaka.core.safety import SafetyGuard
from sadhaka.goals.goal_tree import GoalTree
from sadhaka.recovery.recovery_engine import RecoveryEngine
```

## Architecture: The 4 Pillars

| Pillar | Module | Purpose |
|--------|--------|---------|
| **1. Durable Memory** | `memory/` | Milvus + Blackboard for persistent, queryable state |
| **2. Explicit Tools** | `core/tools.py` | Schema-validated, AST-safe tool execution |
| **3. Specific Goals** | `goals/` | Hierarchical goal trees with progress tracking |
| **4. Recovery Logic** | `recovery/` | Circuit breakers, retries, checkpoints |

## New in v0.2.0

- **Tracing** (`core/tracing.py`): Per-step execution traces with timeline view
- **Safety Guards** (`core/safety.py`): Loop detection, resource cleanup, input validation

## Test Results

```
42/42 tests passing
- VLLMLatentProvider: 5/5 ✓
- MilvusClient: 4/4 ✓
- HealthManager: 3/3 ✓
- Blackboard: 4/4 ✓
- DockerManager: 4/4 ✓
- GoalTree: 5/5 ✓
- RecoveryEngine: 5/5 ✓
- ReActParser: 4/4 ✓
- ToolRegistry: 7/7 ✓
- Integration: 1/1 ✓
```

## Key Features

- **KV-Cache Sharing**: 60-80% token savings with vLLM prefix caching
- **Graceful Degradation**: No vLLM? Mock. No Milvus? In-memory. No Docker? Subprocess.
- **Health Tracking**: Auto-deprecation of failing tools/agents
- **Loop Prevention**: Blocks repeated identical tool calls

## License

MIT
